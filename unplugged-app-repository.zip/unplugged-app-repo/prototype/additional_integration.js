// Update the enhanced_script.js file to integrate the new screens
// Add this code at the end of the existing enhanced_script.js file

// Load additional screens
document.addEventListener('DOMContentLoaded', function() {
  // Load the additional screens script
  const additionalScript = document.createElement('script');
  additionalScript.src = 'additional_screens.js';
  additionalScript.onload = function() {
    // Initialize additional screens after the script loads
    if (typeof initializeAdditionalScreens === 'function') {
      initializeAdditionalScreens();
    }
    
    // Add the additional styles
    if (typeof additionalStyles === 'string') {
      const styleElement = document.createElement('style');
      styleElement.textContent = additionalStyles;
      document.head.appendChild(styleElement);
    }
    
    // Register the new screens in the navigation
    if (typeof plansScreenTemplate === 'string') {
      screenTemplates['plans-screen'] = plansScreenTemplate;
    }
    
    if (typeof communityScreenTemplate === 'string') {
      screenTemplates['community-screen'] = communityScreenTemplate;
    }
    
    // Update navigation handlers to work with new screens
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', function() {
        const screenName = this.getAttribute('data-screen');
        if (screenName && screenTemplates[screenName]) {
          navigateToScreen(screenName);
          
          // Update active nav item
          document.querySelectorAll('.nav-item').forEach(navItem => {
            navItem.classList.remove('active');
          });
          this.classList.add('active');
        }
      });
    });
    
    // Execute any additional scripts
    if (typeof additionalScripts === 'string') {
      try {
        eval(additionalScripts);
      } catch (error) {
        console.error('Error executing additional scripts:', error);
      }
    }
  };
  
  document.body.appendChild(additionalScript);
});
