// Enhanced JavaScript for the Unplugged App Prototype
// Includes additional features and improved functionality

// DOM Elements
const screen = document.getElementById('screen');
const navBar = document.getElementById('nav-bar');

// Screen History for Back Navigation
let screenHistory = [];
let currentScreen = null;

// User Data Store (simulating backend)
const userData = {
    name: 'Alex',
    digitalScore: 78,
    screenTime: {
        today: '3h 45m',
        yesterday: '4h 20m',
        trend: -15
    },
    pickups: {
        today: 42,
        yesterday: 48,
        trend: -8
    },
    focusTime: {
        today: '2h 15m',
        yesterday: '1h 45m',
        trend: 25
    },
    goals: [
        { id: 1, title: 'Reduce screen time by 20%', active: true, progress: 65 },
        { id: 2, title: 'No phone 30 minutes before bed', active: true, progress: 80 },
        { id: 3, title: '2-hour focus periods during work', active: true, progress: 50 },
        { id: 4, title: 'Phone-free meals', active: false, progress: 0 }
    ],
    focusSessions: [
        { date: '2025-04-16', duration: 25, completed: true },
        { date: '2025-04-15', duration: 50, completed: true },
        { date: '2025-04-14', duration: 25, completed: false },
        { date: '2025-04-12', duration: 90, completed: true }
    ],
    appUsage: [
        { name: 'Social Media', time: '1h 20m', percentage: 35 },
        { name: 'Productivity', time: '1h 05m', percentage: 28 },
        { name: 'Entertainment', time: '45m', percentage: 20 },
        { name: 'Communication', time: '35m', percentage: 17 }
    ],
    insights: [
        { id: 1, title: 'Morning Routine', icon: '💡', content: 'You check your phone within 5 minutes of waking up. Consider waiting 30 minutes to start your day more mindfully.' },
        { id: 2, title: 'Evening Usage', icon: '🌙', content: 'Your screen time increases after 9 PM. Try setting a digital sunset alarm to remind you to wind down.' },
        { id: 3, title: 'Focus Improvement', icon: '🎯', content: 'Your focus sessions have increased by 25% this week. Great progress toward your goals!' },
        { id: 4, title: 'App Distribution', icon: '📊', content: 'Social media accounts for 35% of your usage. Consider setting app timers for better balance.' }
    ],
    achievements: [
        { id: 1, title: 'Digital Detox Beginner', icon: '🌱', description: 'Completed your first day under your screen time goal', unlocked: true },
        { id: 2, title: 'Focus Master', icon: '🧠', description: 'Completed 5 focus sessions in one week', unlocked: true },
        { id: 3, title: 'Morning Mindfulness', icon: '☀️', description: 'Avoided phone use for first 30 minutes after waking for 5 days', unlocked: false },
        { id: 4, title: 'Digital Balance', icon: '⚖️', description: 'Maintained healthy screen time for 2 weeks', unlocked: false }
    ]
};

// Theme Support
let currentTheme = 'light';

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    // Start with the welcome screen
    showScreen('welcome-screen');
    
    // Set up event listeners
    setupEventListeners();
    
    // Apply initial theme
    applyTheme(currentTheme);
});

// Function to show a specific screen
function showScreen(screenId, direction = 'forward') {
    // Get the template for the requested screen
    const template = document.getElementById(screenId);
    if (!template) return;
    
    // Clone the template content
    const screenContent = template.content.cloneNode(true);
    
    // If there's a current screen, add it to history unless going back
    if (currentScreen && direction === 'forward') {
        screenHistory.push(currentScreen);
    }
    
    // Set the new current screen
    currentScreen = screenId;
    
    // Clear the screen and add the new content
    const oldScreen = screen.querySelector('.screen');
    
    if (oldScreen) {
        // Apply transition animations
        if (direction === 'forward') {
            oldScreen.classList.add('slide-out-left');
            screenContent.firstElementChild.classList.add('slide-in-right');
        } else {
            oldScreen.classList.add('slide-out-right');
            screenContent.firstElementChild.classList.add('slide-in-left');
        }
        
        // Remove old screen after animation
        setTimeout(() => {
            screen.removeChild(oldScreen);
            screen.appendChild(screenContent);
            setupScreenSpecificListeners(screenId);
            
            // Populate dynamic content
            populateScreenData(screenId);
        }, 300);
    } else {
        screen.appendChild(screenContent);
        setupScreenSpecificListeners(screenId);
        
        // Populate dynamic content
        populateScreenData(screenId);
    }
    
    // Show/hide navigation bar based on screen
    if (['welcome-screen', 'assessment-screen', 'assessment-screen-2', 'assessment-screen-3', 'goal-setting-screen', 'dashboard-intro-screen'].includes(screenId)) {
        navBar.classList.add('hidden');
    } else {
        navBar.classList.remove('hidden');
        updateActiveNavItem(screenId);
    }
}

// Function to populate screen with dynamic data
function populateScreenData(screenId) {
    switch (screenId) {
        case 'dashboard-screen':
            populateDashboardData();
            break;
        case 'focus-mode-screen':
            populateFocusModeData();
            break;
        case 'profile-screen':
            populateProfileData();
            break;
        case 'insights-screen':
            populateInsightsData();
            break;
        case 'achievements-screen':
            populateAchievementsData();
            break;
    }
}

// Populate dashboard with user data
function populateDashboardData() {
    // Update welcome message
    const welcomeHeader = document.querySelector('.dashboard-screen h1');
    if (welcomeHeader) {
        welcomeHeader.textContent = `Welcome Back, ${userData.name}`;
    }
    
    // Update date
    const dateElement = document.querySelector('.date-context');
    if (dateElement) {
        const today = new Date();
        const options = { weekday: 'long', month: 'long', day: 'numeric' };
        dateElement.textContent = today.toLocaleDateString('en-US', options);
    }
    
    // Update digital score
    const scoreNumber = document.querySelector('.score-number');
    if (scoreNumber) {
        scoreNumber.textContent = userData.digitalScore;
    }
    
    // Update score details
    const screenTimeValue = document.querySelector('.score-item:nth-child(1) .score-item-value');
    const screenTimeTrend = document.querySelector('.score-item:nth-child(1) .score-item-trend');
    if (screenTimeValue && screenTimeTrend) {
        screenTimeValue.textContent = userData.screenTime.today;
        screenTimeTrend.textContent = `↓ ${Math.abs(userData.screenTime.trend)}%`;
        screenTimeTrend.className = userData.screenTime.trend < 0 ? 'score-item-trend down' : 'score-item-trend up';
    }
    
    const pickupsValue = document.querySelector('.score-item:nth-child(2) .score-item-value');
    const pickupsTrend = document.querySelector('.score-item:nth-child(2) .score-item-trend');
    if (pickupsValue && pickupsTrend) {
        pickupsValue.textContent = userData.pickups.today;
        pickupsTrend.textContent = `↓ ${Math.abs(userData.pickups.trend)}%`;
        pickupsTrend.className = userData.pickups.trend < 0 ? 'score-item-trend down' : 'score-item-trend up';
    }
    
    const focusTimeValue = document.querySelector('.score-item:nth-child(3) .score-item-value');
    const focusTimeTrend = document.querySelector('.score-item:nth-child(3) .score-item-trend');
    if (focusTimeValue && focusTimeTrend) {
        focusTimeValue.textContent = userData.focusTime.today;
        focusTimeTrend.textContent = `↑ ${userData.focusTime.trend}%`;
        focusTimeTrend.className = userData.focusTime.trend > 0 ? 'score-item-trend up' : 'score-item-trend down';
    }
    
    // Update insights
    const insightsPanel = document.getElementById('insights-panel');
    if (insightsPanel) {
        // Clear existing insights
        while (insightsPanel.firstChild) {
            insightsPanel.removeChild(insightsPanel.firstChild);
        }
        
        // Add insights from user data
        userData.insights.slice(0, 2).forEach(insight => {
            const insightCard = document.createElement('div');
            insightCard.className = 'insight-card';
            insightCard.innerHTML = `
                <div class="insight-icon">${insight.icon}</div>
                <div class="insight-content">
                    <h3>${insight.title}</h3>
                    <p>${insight.content}</p>
                </div>
            `;
            insightsPanel.appendChild(insightCard);
        });
    }
}

// Populate focus mode screen with user data
function populateFocusModeData() {
    // Update focus history if element exists
    const focusHistoryElement = document.querySelector('.focus-history');
    if (focusHistoryElement) {
        // Clear existing history
        while (focusHistoryElement.firstChild) {
            focusHistoryElement.removeChild(focusHistoryElement.firstChild);
        }
        
        // Add history heading
        const historyHeading = document.createElement('h2');
        historyHeading.textContent = 'Recent Focus Sessions';
        focusHistoryElement.appendChild(historyHeading);
        
        // Add focus sessions from user data
        userData.focusSessions.forEach(session => {
            const sessionDate = new Date(session.date);
            const formattedDate = sessionDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            
            const sessionElement = document.createElement('div');
            sessionElement.className = 'history-item';
            sessionElement.innerHTML = `
                <div class="history-date">${formattedDate}</div>
                <div class="history-duration">${session.duration} min</div>
                <div class="history-status ${session.completed ? 'completed' : 'incomplete'}">
                    ${session.completed ? 'Completed' : 'Interrupted'}
                </div>
            `;
            focusHistoryElement.appendChild(sessionElement);
        });
    }
}

// Populate profile screen with user data
function populateProfileData() {
    // Update user name
    const nameElement = document.querySelector('.profile-name');
    if (nameElement) {
        nameElement.textContent = userData.name;
    }
    
    // Update digital score
    const scoreElement = document.querySelector('.profile-score');
    if (scoreElement) {
        scoreElement.textContent = userData.digitalScore;
    }
    
    // Update goals
    const goalsContainer = document.querySelector('.profile-goals');
    if (goalsContainer) {
        // Clear existing goals
        while (goalsContainer.firstChild) {
            goalsContainer.removeChild(goalsContainer.firstChild);
        }
        
        // Add goals heading
        const goalsHeading = document.createElement('h2');
        goalsHeading.textContent = 'Your Goals';
        goalsContainer.appendChild(goalsHeading);
        
        // Add goals from user data
        userData.goals.filter(goal => goal.active).forEach(goal => {
            const goalElement = document.createElement('div');
            goalElement.className = 'profile-goal-item';
            goalElement.innerHTML = `
                <div class="goal-title">${goal.title}</div>
                <div class="goal-progress-bar">
                    <div class="goal-progress-fill" style="width: ${goal.progress}%"></div>
                </div>
                <div class="goal-percentage">${goal.progress}%</div>
            `;
            goalsContainer.appendChild(goalElement);
        });
    }
    
    // Update app usage
    const usageContainer = document.querySelector('.app-usage');
    if (usageContainer) {
        // Clear existing usage data
        while (usageContainer.firstChild) {
            usageContainer.removeChild(usageContainer.firstChild);
        }
        
        // Add usage heading
        const usageHeading = document.createElement('h2');
        usageHeading.textContent = 'App Usage';
        usageContainer.appendChild(usageHeading);
        
        // Add app usage from user data
        userData.appUsage.forEach(app => {
            const appElement = document.createElement('div');
            appElement.className = 'app-usage-item';
            appElement.innerHTML = `
                <div class="app-name">${app.name}</div>
                <div class="app-time">${app.time}</div>
                <div class="app-percentage-bar">
                    <div class="app-percentage-fill" style="width: ${app.percentage}%"></div>
                </div>
                <div class="app-percentage">${app.percentage}%</div>
            `;
            usageContainer.appendChild(appElement);
        });
    }
}

// Populate insights screen with user data
function populateInsightsData() {
    // Update insights container
    const insightsContainer = document.querySelector('.insights-container');
    if (insightsContainer) {
        // Clear existing insights
        while (insightsContainer.firstChild) {
            insightsContainer.removeChild(insightsContainer.firstChild);
        }
        
        // Add insights from user data
        userData.insights.forEach(insight => {
            const insightCard = document.createElement('div');
            insightCard.className = 'insight-card';
            insightCard.innerHTML = `
                <div class="insight-icon">${insight.icon}</div>
                <div class="insight-content">
                    <h3>${insight.title}</h3>
                    <p>${insight.content}</p>
                </div>
                <div class="insight-action">
                    <button class="insight-action-btn">Apply</button>
                </div>
            `;
            insightsContainer.appendChild(insightCard);
            
            // Add event listener to action button
            const actionBtn = insightCard.querySelector('.insight-action-btn');
            if (actionBtn) {
                actionBtn.addEventListener('click', () => {
                    showToast(`Applied insight: ${insight.title}`);
                });
            }
        });
    }
}

// Populate achievements screen with user data
function populateAchievementsData() {
    // Update achievements container
    const achievementsContainer = document.querySelector('.achievements-container');
    if (achievementsContainer) {
        // Clear existing achievements
        while (achievementsContainer.firstChild) {
            achievementsContainer.removeChild(achievementsContainer.firstChild);
        }
        
        // Add achievements from user data
        userData.achievements.forEach(achievement => {
            const achievementCard = document.createElement('div');
            achievementCard.className = `achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}`;
            achievementCard.innerHTML = `
                <div class="achievement-icon">${achievement.icon}</div>
                <div class="achievement-content">
                    <h3>${achievement.title}</h3>
                    <p>${achievement.description}</p>
                </div>
                <div class="achievement-status">
                    ${achievement.unlocked ? 'Unlocked' : 'Locked'}
                </div>
            `;
            achievementsContainer.appendChild(achievementCard);
        });
    }
}

// Function to go back to the previous screen
function goBack() {
    if (screenHistory.length > 0) {
        const previousScreen = screenHistory.pop();
        showScreen(previousScreen, 'back');
    }
}

// Set up global event listeners
function setupEventListeners() {
    // Navigation bar event listeners
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            const screenId = item.getAttribute('data-screen');
            if (screenId) {
                showScreen(screenId);
            }
        });
    });
    
    // Back button functionality (for browser testing)
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            goBack();
        }
    });
    
    // Theme toggle (if exists in DOM)
    document.addEventListener('click', (e) => {
        if (e.target.id === 'theme-toggle' || e.target.closest('#theme-toggle')) {
            toggleTheme();
        }
    });
}

// Set up screen-specific event listeners
function setupScreenSpecificListeners(screenId) {
    switch (screenId) {
        case 'welcome-screen':
            setupWelcomeScreen();
            break;
        case 'assessment-screen':
            setupAssessmentScreen();
            break;
        case 'assessment-screen-2':
            setupAssessmentScreen2();
            break;
        case 'assessment-screen-3':
            setupAssessmentScreen3();
            break;
        case 'goal-setting-screen':
            setupGoalSettingScreen();
            break;
        case 'dashboard-intro-screen':
            setupDashboardIntroScreen();
            break;
        case 'dashboard-screen':
            setupDashboardScreen();
            break;
        case 'tools-screen':
            setupToolsScreen();
            break;
        case 'focus-mode-screen':
            setupFocusModeScreen();
            break;
        case 'profile-screen':
            setupProfileScreen();
            break;
        case 'insights-screen':
            setupInsightsScreen();
            break;
        case 'achievements-screen':
            setupAchievementsScreen();
            break;
        case 'settings-screen':
            setupSettingsScreen();
            break;
    }
}

// Update active navigation item
function updateActiveNavItem(screenId) {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    let activeSection = '';
    
    if (screenId === 'dashboard-screen') {
        activeSection = 'dashboard';
    } else if (screenId === 'tools-screen' || screenId === 'focus-mode-screen') {
        activeSection = 'tools';
    } else if (screenId.includes('plan')) {
        activeSection = 'plans';
    } else if (screenId.includes('community')) {
        activeSection = 'community';
    } else if (screenId.includes('profile') || screenId === 'insights-screen' || screenId === 'achievements-screen' || screenId === 'settings-screen') {
        activeSection = 'profile';
    }
    
    const activeItem = document.querySelector(`.nav-item[data-screen="${activeSection}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
}

// Welcome Screen Setup
function setupWelcomeScreen() {
    const getStartedBtn = document.getElementById('get-started-btn');
    const signInLink = document.getElementById('sign-in-link');
    
    if (getStartedBtn) {
        getStartedBtn.addEventListener('click', () => {
            showScreen('assessment-screen');
        });
    }
    
    if (signInLink) {
        signInLink.addEventListener('click', () => {
            showToast('Sign in functionality would be implemented in the full app');
        });
    }
}

// Assessment Screen Setup
function setupAssessmentScreen() {
    const options = document.querySelectorAll('.assessment-screen .option');
    const nextBtn = document.getElementById('next-btn');
    const backBtn = document.getElementById('back-btn');
    
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
        });
    });
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            const selectedOption = document.querySelector('.assessment-screen .option.selected');
            if (selectedOption) {
                showScreen('assessment-screen-2');
            } else {
                showToast('Please select an option to continue');
            }
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Assessment Screen 2 Setup
function setupAssessmentScreen2() {
    const options = document.querySelectorAll('.assessment-screen .multi-select .option');
    const nextBtn = document.getElementById('next-btn-2');
    const backBtn = document.getElementById('back-btn-2');
    
    options.forEach(option => {
        option.addEventListener('click', () => {
            const checkbox = option.querySelector('.checkbox');
            checkbox.classList.toggle('checked');
        });
    });
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            const checkedOptions = document.querySelectorAll('.assessment-screen .multi-select .checkbox.checked');
            if (checkedOptions.length > 0) {
                showScreen('assessment-screen-3');
            } else {
                showToast('Please select at least one option to continue');
            }
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Assessment Screen 3 Setup
function setupAssessmentScreen3() {
    const options = document.querySelectorAll('.assessment-screen .option');
    const completeBtn = document.getElementById('complete-btn');
    const backBtn = document.getElementById('back-btn-3');
    
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
        });
    });
    
    if (completeBtn) {
        completeBtn.addEventListener('click', () => {
            const selectedOption = document.querySelector('.assessment-screen .option.selected');
            if (selectedOption) {
                showScreen('goal-setting-screen');
            } else {
                showToast('Please select an option to continue');
            }
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Goal Setting Screen Setup
function setupGoalSettingScreen() {
    const goalToggles = document.querySelectorAll('.goal-toggle');
    const setGoalsBtn = document.getElementById('set-goals-btn');
    const addCustomGoalBtn = document.getElementById('add-custom-goal-btn');
    const adjustLaterLink = document.getElementById('adjust-later-link');
    
    goalToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
        });
    });
    
    if (setGoalsBtn) {
        setGoalsBtn.addEventListener('click', () => {
            const activeGoals = document.querySelectorAll('.goal-toggle.active');
            if (activeGoals.length > 0) {
                showScreen('dashboard-intro-screen');
            } else {
                showToast('Please select at least one goal to continue');
            }
        });
    }
    
    if (addCustomGoalBtn) {
        addCustomGoalBtn.addEventListener('click', () => {
            showCustomGoalModal();
        });
    }
    
    if (adjustLaterLink) {
        adjustLaterLink.addEventListener('click', () => {
            showScreen('dashboard-intro-screen');
        });
    }
}

// Dashboard Intro Screen Setup
function setupDashboardIntroScreen() {
    const letsBeginBtn = document.getElementById('lets-begin-btn');
    const takeTourLink = document.getElementById('take-tour-link');
    
    if (letsBeginBtn) {
        letsBeginBtn.addEventListener('click', () => {
            showScreen('dashboard-screen');
        });
    }
    
    if (takeTourLink) {
        takeTourLink.addEventListener('click', () => {
            startGuidedTour();
        });
    }
}

// Dashboard Screen Setup
function setupDashboardScreen() {
    const tabs = document.querySelectorAll('.dashboard-tabs .tab');
    const celebrateBtn = document.getElementById('celebrate-btn');
    const achievementsBtn = document.getElementById('achievements-btn');
    const focusModeBtn = document.getElementById('focus-mode-btn');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            
            // Update active tab
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Show corresponding panel
            document.querySelectorAll('.dashboard-panels .panel').forEach(panel => {
                panel.classList.remove('active');
            });
            document.getElementById(`${tabId}-panel`).classList.add('active');
        });
    });
    
    if (celebrateBtn) {
        celebrateBtn.addEventListener('click', () => {
            showCelebrationModal();
        });
    }
    
    if (achievementsBtn) {
        achievementsBtn.addEventListener('click', () => {
            showScreen('achievements-screen');
        });
    }
    
    if (focusModeBtn) {
        focusModeBtn.addEventListener('click', () => {
            showScreen('focus-mode-screen');
        });
    }
}

// Tools Screen Setup
function setupToolsScreen() {
    const focusModeCard = document.getElementById('focus-mode-card');
    const intentionSetterCard = document.getElementById('intention-setter-card');
    const mindfulBreakCard = document.getElementById('mindful-break-card');
    const usageAwarenessCard = document.getElementById('usage-awareness-card');
    const sleepImprovementCard = document.getElementById('sleep-improvement-card');
    
    if (focusModeCard) {
        focusModeCard.addEventListener('click', () => {
            showScreen('focus-mode-screen');
        });
    }
    
    if (intentionSetterCard) {
        intentionSetterCard.addEventListener('click', () => {
            showToast('Intention Setter tool would be implemented in the full app');
        });
    }
    
    if (mindfulBreakCard) {
        mindfulBreakCard.addEventListener('click', () => {
            showToast('Mindful Break tool would be implemented in the full app');
        });
    }
    
    if (usageAwarenessCard) {
        usageAwarenessCard.addEventListener('click', () => {
            showToast('Usage Awareness tool would be implemented in the full app');
        });
    }
    
    if (sleepImprovementCard) {
        sleepImprovementCard.addEventListener('click', () => {
            showToast('Sleep Improvement tool would be implemented in the full app');
        });
    }
}

// Focus Mode Screen Setup
function setupFocusModeScreen() {
    const optionCards = document.querySelectorAll('.option-card');
    const toggles = document.querySelectorAll('.toggle');
    const startFocusBtn = document.getElementById('start-focus-btn');
    const scheduleLaterLink = document.getElementById('schedule-later-link');
    
    optionCards.forEach(card => {
        card.addEventListener('click', () => {
            optionCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            
            // Update timer display based on selected option
            const timerDisplay = document.querySelector('.timer-display');
            if (timerDisplay) {
                if (card.querySelector('.option-label').textContent === 'Quick Focus') {
                    timerDisplay.textContent = '25:00';
                } else if (card.querySelector('.option-label').textContent === 'Standard Focus') {
                    timerDisplay.textContent = '50:00';
                } else if (card.querySelector('.option-label').textContent === 'Deep Focus') {
                    timerDisplay.textContent = '90:00';
                }
            }
        });
    });
    
    toggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
        });
    });
    
    if (startFocusBtn) {
        startFocusBtn.addEventListener('click', () => {
            startFocusSession();
        });
    }
    
    if (scheduleLaterLink) {
        scheduleLaterLink.addEventListener('click', () => {
            showScheduleModal();
        });
    }
}

// Profile Screen Setup
function setupProfileScreen() {
    const editProfileBtn = document.getElementById('edit-profile-btn');
    const viewInsightsBtn = document.getElementById('view-insights-btn');
    const viewAchievementsBtn = document.getElementById('view-achievements-btn');
    const settingsBtn = document.getElementById('settings-btn');
    
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', () => {
            showToast('Profile editing would be implemented in the full app');
        });
    }
    
    if (viewInsightsBtn) {
        viewInsightsBtn.addEventListener('click', () => {
            showScreen('insights-screen');
        });
    }
    
    if (viewAchievementsBtn) {
        viewAchievementsBtn.addEventListener('click', () => {
            showScreen('achievements-screen');
        });
    }
    
    if (settingsBtn) {
        settingsBtn.addEventListener('click', () => {
            showScreen('settings-screen');
        });
    }
}

// Insights Screen Setup
function setupInsightsScreen() {
    const backBtn = document.getElementById('insights-back-btn');
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Achievements Screen Setup
function setupAchievementsScreen() {
    const backBtn = document.getElementById('achievements-back-btn');
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Settings Screen Setup
function setupSettingsScreen() {
    const backBtn = document.getElementById('settings-back-btn');
    const themeToggle = document.getElementById('theme-toggle');
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
    
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            toggleTheme();
        });
    }
}

// Theme Toggle Function
function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(currentTheme);
    showToast(`Switched to ${currentTheme} theme`);
}

// Apply Theme Function
function applyTheme(theme) {
    document.body.classList.remove('light-theme', 'dark-theme');
    document.body.classList.add(`${theme}-theme`);
    
    // Update theme toggle if it exists
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.textContent = theme === 'light' ? '🌙' : '☀️';
    }
}

// Show Toast Message
function showToast(message) {
    // Remove existing toast if any
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create new toast
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    
    // Add to body
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Hide toast after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Show Custom Goal Modal
function showCustomGoalModal() {
    // Create modal container
    const modalContainer = document.createElement('div');
    modalContainer.className = 'modal-container';
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content';
    modalContent.innerHTML = `
        <h2>Create Custom Goal</h2>
        <div class="modal-form">
            <div class="form-group">
                <label for="goal-title">Goal Title</label>
                <input type="text" id="goal-title" placeholder="e.g., Limit social media to 30 minutes">
            </div>
            <div class="form-group">
                <label for="goal-category">Category</label>
                <select id="goal-category">
                    <option value="screen-time">Screen Time</option>
                    <option value="focus">Focus</option>
                    <option value="mindfulness">Mindfulness</option>
                    <option value="sleep">Sleep</option>
                </select>
            </div>
            <div class="form-group">
                <label for="goal-duration">Duration</label>
                <select id="goal-duration">
                    <option value="1-week">1 Week</option>
                    <option value="2-weeks">2 Weeks</option>
                    <option value="1-month">1 Month</option>
                    <option value="ongoing">Ongoing</option>
                </select>
            </div>
        </div>
        <div class="modal-actions">
            <button class="secondary-button" id="cancel-goal-btn">Cancel</button>
            <button class="primary-button" id="save-goal-btn">Save Goal</button>
        </div>
    `;
    
    // Add modal to container
    modalContainer.appendChild(modalContent);
    
    // Add to body
    document.body.appendChild(modalContainer);
    
    // Show modal with animation
    setTimeout(() => {
        modalContent.style.transform = 'translateY(0)';
        modalContent.style.opacity = '1';
    }, 10);
    
    // Set up event listeners
    const cancelBtn = document.getElementById('cancel-goal-btn');
    const saveBtn = document.getElementById('save-goal-btn');
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            closeModal(modalContainer, modalContent);
        });
    }
    
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            const goalTitle = document.getElementById('goal-title').value;
            if (goalTitle.trim() === '') {
                showToast('Please enter a goal title');
                return;
            }
            
            // In a real app, this would save the goal to the database
            showToast('Custom goal created successfully');
            closeModal(modalContainer, modalContent);
            
            // Add the goal to the goals list
            const goalsContainer = document.querySelector('.goals-container');
            if (goalsContainer) {
                const newGoalItem = document.createElement('div');
                newGoalItem.className = 'goal-item';
                newGoalItem.innerHTML = `
                    <div class="goal-toggle active"></div>
                    <div class="goal-text">${goalTitle}</div>
                `;
                goalsContainer.appendChild(newGoalItem);
                
                // Add event listener to the new toggle
                const newToggle = newGoalItem.querySelector('.goal-toggle');
                if (newToggle) {
                    newToggle.addEventListener('click', () => {
                        newToggle.classList.toggle('active');
                    });
                }
            }
        });
    }
}

// Show Celebration Modal
function showCelebrationModal() {
    // Create modal container
    const modalContainer = document.createElement('div');
    modalContainer.className = 'modal-container celebration-modal';
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content';
    modalContent.innerHTML = `
        <div class="celebration-content">
            <div class="celebration-icon">🎉</div>
            <h2>Great Progress!</h2>
            <p>You've reduced your screen time by 15% this week.</p>
            <p class="celebration-stat">That's 4 hours and 12 minutes reclaimed!</p>
            <div class="celebration-suggestion">
                <h3>How will you use this time?</h3>
                <div class="suggestion-options">
                    <div class="suggestion-option">Reading</div>
                    <div class="suggestion-option">Exercise</div>
                    <div class="suggestion-option">Socializing</div>
                    <div class="suggestion-option">Hobbies</div>
                </div>
            </div>
            <button class="primary-button" id="close-celebration-btn">Continue</button>
        </div>
    `;
    
    // Add confetti animation
    for (let i = 0; i < 50; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = `${Math.random() * 100}%`;
        confetti.style.animationDelay = `${Math.random() * 3}s`;
        confetti.style.backgroundColor = `hsl(${Math.random() * 360}, 80%, 60%)`;
        modalContainer.appendChild(confetti);
    }
    
    // Add modal to container
    modalContainer.appendChild(modalContent);
    
    // Add to body
    document.body.appendChild(modalContainer);
    
    // Show modal with animation
    setTimeout(() => {
        modalContent.style.transform = 'translateY(0)';
        modalContent.style.opacity = '1';
    }, 10);
    
    // Set up event listeners
    const closeBtn = document.getElementById('close-celebration-btn');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            closeModal(modalContainer, modalContent);
        });
    }
    
    // Set up suggestion options
    const suggestionOptions = document.querySelectorAll('.suggestion-option');
    
    suggestionOptions.forEach(option => {
        option.addEventListener('click', () => {
            suggestionOptions.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
        });
    });
}

// Show Schedule Modal
function showScheduleModal() {
    // Create modal container
    const modalContainer = document.createElement('div');
    modalContainer.className = 'modal-container';
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content';
    modalContent.innerHTML = `
        <h2>Schedule Focus Session</h2>
        <div class="modal-form">
            <div class="form-group">
                <label for="session-date">Date</label>
                <input type="date" id="session-date" value="${new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group">
                <label for="session-time">Time</label>
                <input type="time" id="session-time" value="09:00">
            </div>
            <div class="form-group">
                <label for="session-duration">Duration</label>
                <select id="session-duration">
                    <option value="25">25 minutes</option>
                    <option value="50">50 minutes</option>
                    <option value="90">90 minutes</option>
                </select>
            </div>
            <div class="form-group">
                <label for="session-repeat">Repeat</label>
                <select id="session-repeat">
                    <option value="none">Don't repeat</option>
                    <option value="daily">Daily</option>
                    <option value="weekdays">Weekdays</option>
                    <option value="weekly">Weekly</option>
                </select>
            </div>
        </div>
        <div class="modal-actions">
            <button class="secondary-button" id="cancel-schedule-btn">Cancel</button>
            <button class="primary-button" id="save-schedule-btn">Schedule</button>
        </div>
    `;
    
    // Add modal to container
    modalContainer.appendChild(modalContent);
    
    // Add to body
    document.body.appendChild(modalContainer);
    
    // Show modal with animation
    setTimeout(() => {
        modalContent.style.transform = 'translateY(0)';
        modalContent.style.opacity = '1';
    }, 10);
    
    // Set up event listeners
    const cancelBtn = document.getElementById('cancel-schedule-btn');
    const saveBtn = document.getElementById('save-schedule-btn');
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            closeModal(modalContainer, modalContent);
        });
    }
    
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            // In a real app, this would save the schedule to the database
            showToast('Focus session scheduled successfully');
            closeModal(modalContainer, modalContent);
        });
    }
}

// Start Focus Session
function startFocusSession() {
    // Get selected duration
    const activeOption = document.querySelector('.option-card.active');
    let duration = 25; // Default to 25 minutes
    
    if (activeOption) {
        const optionLabel = activeOption.querySelector('.option-label').textContent;
        if (optionLabel === 'Quick Focus') {
            duration = 25;
        } else if (optionLabel === 'Standard Focus') {
            duration = 50;
        } else if (optionLabel === 'Deep Focus') {
            duration = 90;
        } else if (optionLabel === 'Custom Duration') {
            const customInput = activeOption.querySelector('input');
            if (customInput) {
                duration = parseInt(customInput.value) || 25;
            }
        }
    }
    
    // Update UI to show active focus mode
    const statusElement = document.querySelector('.status');
    if (statusElement) {
        statusElement.textContent = 'Focus Mode Active';
        statusElement.classList.add('active');
    }
    
    const timerCircle = document.querySelector('.timer-circle');
    if (timerCircle) {
        timerCircle.classList.add('active');
    }
    
    const startBtn = document.getElementById('start-focus-btn');
    if (startBtn) {
        startBtn.textContent = 'End Focus Session';
        startBtn.classList.add('end-session');
        
        // Change event listener
        startBtn.removeEventListener('click', startFocusSession);
        startBtn.addEventListener('click', endFocusSession);
    }
    
    // Start countdown
    startCountdown(duration * 60); // Convert minutes to seconds
    
    // Show toast
    showToast(`Focus session started for ${duration} minutes`);
}

// End Focus Session
function endFocusSession() {
    // Update UI to show inactive focus mode
    const statusElement = document.querySelector('.status');
    if (statusElement) {
        statusElement.textContent = 'Focus Mode Off';
        statusElement.classList.remove('active');
    }
    
    const timerCircle = document.querySelector('.timer-circle');
    if (timerCircle) {
        timerCircle.classList.remove('active');
    }
    
    const startBtn = document.getElementById('start-focus-btn');
    if (startBtn) {
        startBtn.textContent = 'Start Focus Session';
        startBtn.classList.remove('end-session');
        
        // Change event listener back
        startBtn.removeEventListener('click', endFocusSession);
        startBtn.addEventListener('click', startFocusSession);
    }
    
    // Stop countdown
    stopCountdown();
    
    // Show toast
    showToast('Focus session ended');
}

// Countdown variables
let countdownInterval;
let remainingSeconds;

// Start Countdown
function startCountdown(seconds) {
    // Clear any existing countdown
    stopCountdown();
    
    // Set initial remaining seconds
    remainingSeconds = seconds;
    
    // Update timer display
    updateTimerDisplay();
    
    // Start interval
    countdownInterval = setInterval(() => {
        remainingSeconds--;
        
        // Update timer display
        updateTimerDisplay();
        
        // Check if countdown is complete
        if (remainingSeconds <= 0) {
            completeFocusSession();
        }
    }, 1000);
}

// Stop Countdown
function stopCountdown() {
    clearInterval(countdownInterval);
}

// Update Timer Display
function updateTimerDisplay() {
    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    
    const timerDisplay = document.querySelector('.timer-display');
    if (timerDisplay) {
        timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // Update progress circle
    const timerProgress = document.querySelector('.timer-progress');
    if (timerProgress) {
        const activeOption = document.querySelector('.option-card.active');
        let totalDuration = 25 * 60; // Default to 25 minutes in seconds
        
        if (activeOption) {
            const optionLabel = activeOption.querySelector('.option-label').textContent;
            if (optionLabel === 'Quick Focus') {
                totalDuration = 25 * 60;
            } else if (optionLabel === 'Standard Focus') {
                totalDuration = 50 * 60;
            } else if (optionLabel === 'Deep Focus') {
                totalDuration = 90 * 60;
            } else if (optionLabel === 'Custom Duration') {
                const customInput = activeOption.querySelector('input');
                if (customInput) {
                    totalDuration = (parseInt(customInput.value) || 25) * 60;
                }
            }
        }
        
        const progressPercentage = (1 - (remainingSeconds / totalDuration)) * 100;
        timerProgress.style.background = `conic-gradient(#00c853 ${progressPercentage}%, transparent ${progressPercentage}%)`;
    }
}

// Complete Focus Session
function completeFocusSession() {
    // Stop countdown
    stopCountdown();
    
    // Show completion modal
    showFocusCompletionModal();
    
    // Reset UI
    endFocusSession();
}

// Show Focus Completion Modal
function showFocusCompletionModal() {
    // Create modal container
    const modalContainer = document.createElement('div');
    modalContainer.className = 'modal-container celebration-modal';
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content';
    modalContent.innerHTML = `
        <div class="celebration-content">
            <div class="celebration-icon">✅</div>
            <h2>Focus Session Complete!</h2>
            <p>Great job staying focused and avoiding distractions.</p>
            <div class="focus-stats">
                <div class="focus-stat">
                    <div class="stat-value">100%</div>
                    <div class="stat-label">Completion</div>
                </div>
                <div class="focus-stat">
                    <div class="stat-value">0</div>
                    <div class="stat-label">Interruptions</div>
                </div>
                <div class="focus-stat">
                    <div class="stat-value">+5</div>
                    <div class="stat-label">Score Points</div>
                </div>
            </div>
            <p class="focus-question">How productive was your session?</p>
            <div class="rating-container">
                <div class="rating-option">😞</div>
                <div class="rating-option">😐</div>
                <div class="rating-option">🙂</div>
                <div class="rating-option">😀</div>
                <div class="rating-option">🤩</div>
            </div>
            <button class="primary-button" id="close-focus-completion-btn">Continue</button>
        </div>
    `;
    
    // Add confetti animation
    for (let i = 0; i < 30; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = `${Math.random() * 100}%`;
        confetti.style.animationDelay = `${Math.random() * 2}s`;
        confetti.style.backgroundColor = `hsl(${Math.random() * 120 + 100}, 80%, 60%)`;
        modalContainer.appendChild(confetti);
    }
    
    // Add modal to container
    modalContainer.appendChild(modalContent);
    
    // Add to body
    document.body.appendChild(modalContainer);
    
    // Show modal with animation
    setTimeout(() => {
        modalContent.style.transform = 'translateY(0)';
        modalContent.style.opacity = '1';
    }, 10);
    
    // Set up event listeners
    const closeBtn = document.getElementById('close-focus-completion-btn');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            closeModal(modalContainer, modalContent);
            showScreen('dashboard-screen');
        });
    }
    
    // Set up rating options
    const ratingOptions = document.querySelectorAll('.rating-option');
    
    ratingOptions.forEach((option, index) => {
        option.addEventListener('click', () => {
            ratingOptions.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
        });
    });
}

// Start Guided Tour
function startGuidedTour() {
    // Create tour overlay
    const tourOverlay = document.createElement('div');
    tourOverlay.className = 'tour-overlay';
    
    // Create tour content
    const tourContent = document.createElement('div');
    tourContent.className = 'tour-content';
    
    // Define tour steps
    const tourSteps = [
        {
            title: 'Welcome to Your Dashboard',
            content: 'This is your digital wellbeing dashboard. It provides an overview of your digital habits and progress toward your goals.',
            target: '.dashboard-intro-content h1',
            position: 'bottom'
        },
        {
            title: 'Digital Score',
            content: 'Your Digital Score shows your overall digital wellbeing. It\'s calculated based on your screen time, app usage, and goal progress.',
            target: '.dashboard-section:nth-child(1)',
            position: 'right'
        },
        {
            title: 'Usage Patterns',
            content: 'Track your app usage trends to understand where your digital time is spent.',
            target: '.dashboard-section:nth-child(2)',
            position: 'right'
        },
        {
            title: 'Goal Progress',
            content: 'Monitor your progress toward your digital wellbeing goals.',
            target: '.dashboard-section:nth-child(3)',
            position: 'left'
        },
        {
            title: 'Insights',
            content: 'Get personalized insights and recommendations based on your usage patterns.',
            target: '.dashboard-section:nth-child(4)',
            position: 'left'
        },
        {
            title: 'Let\'s Begin!',
            content: 'Click "Let\'s Begin" to start your digital wellbeing journey.',
            target: '#lets-begin-btn',
            position: 'top'
        }
    ];
    
    // Set initial tour step
    let currentTourStep = 0;
    
    // Function to show tour step
    function showTourStep(step) {
        // Update tour content
        tourContent.innerHTML = `
            <h3>${tourSteps[step].title}</h3>
            <p>${tourSteps[step].content}</p>
            <div class="tour-navigation">
                <button class="tour-btn" id="tour-prev-btn" ${step === 0 ? 'disabled' : ''}>Previous</button>
                <div class="tour-progress">
                    <span class="tour-step">${step + 1}</span>/<span class="tour-total">${tourSteps.length}</span>
                </div>
                <button class="tour-btn" id="tour-next-btn">${step === tourSteps.length - 1 ? 'Finish' : 'Next'}</button>
            </div>
        `;
        
        // Position tour content
        const targetElement = document.querySelector(tourSteps[step].target);
        if (targetElement) {
            const targetRect = targetElement.getBoundingClientRect();
            const position = tourSteps[step].position;
            
            // Highlight target element
            targetElement.classList.add('tour-highlight');
            
            // Position tour content based on position
            switch (position) {
                case 'top':
                    tourContent.style.top = `${targetRect.top - tourContent.offsetHeight - 10}px`;
                    tourContent.style.left = `${targetRect.left + (targetRect.width / 2) - (tourContent.offsetWidth / 2)}px`;
                    break;
                case 'right':
                    tourContent.style.top = `${targetRect.top + (targetRect.height / 2) - (tourContent.offsetHeight / 2)}px`;
                    tourContent.style.left = `${targetRect.right + 10}px`;
                    break;
                case 'bottom':
                    tourContent.style.top = `${targetRect.bottom + 10}px`;
                    tourContent.style.left = `${targetRect.left + (targetRect.width / 2) - (tourContent.offsetWidth / 2)}px`;
                    break;
                case 'left':
                    tourContent.style.top = `${targetRect.top + (targetRect.height / 2) - (tourContent.offsetHeight / 2)}px`;
                    tourContent.style.left = `${targetRect.left - tourContent.offsetWidth - 10}px`;
                    break;
            }
        }
        
        // Set up event listeners
        const prevBtn = document.getElementById('tour-prev-btn');
        const nextBtn = document.getElementById('tour-next-btn');
        
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (currentTourStep > 0) {
                    // Remove highlight from current target
                    const currentTarget = document.querySelector(tourSteps[currentTourStep].target);
                    if (currentTarget) {
                        currentTarget.classList.remove('tour-highlight');
                    }
                    
                    currentTourStep--;
                    showTourStep(currentTourStep);
                }
            });
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                if (currentTourStep < tourSteps.length - 1) {
                    // Remove highlight from current target
                    const currentTarget = document.querySelector(tourSteps[currentTourStep].target);
                    if (currentTarget) {
                        currentTarget.classList.remove('tour-highlight');
                    }
                    
                    currentTourStep++;
                    showTourStep(currentTourStep);
                } else {
                    // End tour
                    endTour();
                }
            });
        }
    }
    
    // Function to end tour
    function endTour() {
        // Remove highlight from current target
        const currentTarget = document.querySelector(tourSteps[currentTourStep].target);
        if (currentTarget) {
            currentTarget.classList.remove('tour-highlight');
        }
        
        // Remove tour overlay and content
        document.body.removeChild(tourOverlay);
        
        // Show toast
        showToast('Tour completed! Click "Let\'s Begin" to continue.');
    }
    
    // Add tour content to overlay
    tourOverlay.appendChild(tourContent);
    
    // Add overlay to body
    document.body.appendChild(tourOverlay);
    
    // Show first tour step
    showTourStep(currentTourStep);
}

// Close Modal Function
function closeModal(modalContainer, modalContent) {
    // Hide modal with animation
    modalContent.style.transform = 'translateY(20px)';
    modalContent.style.opacity = '0';
    
    // Remove modal after animation
    setTimeout(() => {
        document.body.removeChild(modalContainer);
    }, 300);
}
