// Main JavaScript for the Unplugged App Prototype

// DOM Elements
const screen = document.getElementById('screen');
const navBar = document.getElementById('nav-bar');

// Screen History for Back Navigation
let screenHistory = [];
let currentScreen = null;

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    // Start with the welcome screen
    showScreen('welcome-screen');
    
    // Set up event listeners
    setupEventListeners();
});

// Function to show a specific screen
function showScreen(screenId, direction = 'forward') {
    // Get the template for the requested screen
    const template = document.getElementById(screenId);
    if (!template) return;
    
    // Clone the template content
    const screenContent = template.content.cloneNode(true);
    
    // If there's a current screen, add it to history unless going back
    if (currentScreen && direction === 'forward') {
        screenHistory.push(currentScreen);
    }
    
    // Set the new current screen
    currentScreen = screenId;
    
    // Clear the screen and add the new content
    const oldScreen = screen.querySelector('.screen');
    
    if (oldScreen) {
        // Apply transition animations
        if (direction === 'forward') {
            oldScreen.classList.add('slide-out-left');
            screenContent.firstElementChild.classList.add('slide-in-right');
        } else {
            oldScreen.classList.add('slide-out-right');
            screenContent.firstElementChild.classList.add('slide-in-left');
        }
        
        // Remove old screen after animation
        setTimeout(() => {
            screen.removeChild(oldScreen);
            screen.appendChild(screenContent);
            setupScreenSpecificListeners(screenId);
        }, 300);
    } else {
        screen.appendChild(screenContent);
        setupScreenSpecificListeners(screenId);
    }
    
    // Show/hide navigation bar based on screen
    if (['welcome-screen', 'assessment-screen', 'assessment-screen-2', 'assessment-screen-3', 'goal-setting-screen', 'dashboard-intro-screen'].includes(screenId)) {
        navBar.classList.add('hidden');
    } else {
        navBar.classList.remove('hidden');
        updateActiveNavItem(screenId);
    }
}

// Function to go back to the previous screen
function goBack() {
    if (screenHistory.length > 0) {
        const previousScreen = screenHistory.pop();
        showScreen(previousScreen, 'back');
    }
}

// Set up global event listeners
function setupEventListeners() {
    // Navigation bar event listeners
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            const screenId = item.getAttribute('data-screen');
            if (screenId) {
                showScreen(screenId);
            }
        });
    });
    
    // Back button functionality (for browser testing)
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            goBack();
        }
    });
}

// Set up screen-specific event listeners
function setupScreenSpecificListeners(screenId) {
    switch (screenId) {
        case 'welcome-screen':
            setupWelcomeScreen();
            break;
        case 'assessment-screen':
            setupAssessmentScreen();
            break;
        case 'assessment-screen-2':
            setupAssessmentScreen2();
            break;
        case 'assessment-screen-3':
            setupAssessmentScreen3();
            break;
        case 'goal-setting-screen':
            setupGoalSettingScreen();
            break;
        case 'dashboard-intro-screen':
            setupDashboardIntroScreen();
            break;
        case 'dashboard-screen':
            setupDashboardScreen();
            break;
        case 'tools-screen':
            setupToolsScreen();
            break;
        case 'focus-mode-screen':
            setupFocusModeScreen();
            break;
    }
}

// Update active navigation item
function updateActiveNavItem(screenId) {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    let activeSection = '';
    
    if (screenId === 'dashboard-screen') {
        activeSection = 'dashboard';
    } else if (screenId === 'tools-screen' || screenId === 'focus-mode-screen') {
        activeSection = 'tools';
    } else if (screenId.includes('plan')) {
        activeSection = 'plans';
    } else if (screenId.includes('community')) {
        activeSection = 'community';
    } else if (screenId.includes('profile')) {
        activeSection = 'profile';
    }
    
    const activeItem = document.querySelector(`.nav-item[data-screen="${activeSection}"]`);
    if (activeItem) {
        activeItem.classList.add('active');
    }
}

// Welcome Screen Setup
function setupWelcomeScreen() {
    const getStartedBtn = document.getElementById('get-started-btn');
    const signInLink = document.getElementById('sign-in-link');
    
    if (getStartedBtn) {
        getStartedBtn.addEventListener('click', () => {
            showScreen('assessment-screen');
        });
    }
    
    if (signInLink) {
        signInLink.addEventListener('click', () => {
            // In a real app, this would show a sign-in form
            alert('Sign in functionality would be implemented here.');
        });
    }
}

// Assessment Screen Setup
function setupAssessmentScreen() {
    const options = document.querySelectorAll('.assessment-screen .option');
    const nextBtn = document.getElementById('next-btn');
    const backBtn = document.getElementById('back-btn');
    
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
        });
    });
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            showScreen('assessment-screen-2');
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Assessment Screen 2 Setup
function setupAssessmentScreen2() {
    const options = document.querySelectorAll('.assessment-screen .multi-select .option');
    const nextBtn = document.getElementById('next-btn-2');
    const backBtn = document.getElementById('back-btn-2');
    
    options.forEach(option => {
        option.addEventListener('click', () => {
            const checkbox = option.querySelector('.checkbox');
            checkbox.classList.toggle('checked');
        });
    });
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            showScreen('assessment-screen-3');
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Assessment Screen 3 Setup
function setupAssessmentScreen3() {
    const options = document.querySelectorAll('.assessment-screen .option');
    const completeBtn = document.getElementById('complete-btn');
    const backBtn = document.getElementById('back-btn-3');
    
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
        });
    });
    
    if (completeBtn) {
        completeBtn.addEventListener('click', () => {
            showScreen('goal-setting-screen');
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            goBack();
        });
    }
}

// Goal Setting Screen Setup
function setupGoalSettingScreen() {
    const goalToggles = document.querySelectorAll('.goal-toggle');
    const setGoalsBtn = document.getElementById('set-goals-btn');
    const addCustomGoalBtn = document.getElementById('add-custom-goal-btn');
    const adjustLaterLink = document.getElementById('adjust-later-link');
    
    goalToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
        });
    });
    
    if (setGoalsBtn) {
        setGoalsBtn.addEventListener('click', () => {
            showScreen('dashboard-intro-screen');
        });
    }
    
    if (addCustomGoalBtn) {
        addCustomGoalBtn.addEventListener('click', () => {
            // In a real app, this would show a custom goal form
            alert('Custom goal creation would be implemented here.');
        });
    }
    
    if (adjustLaterLink) {
        adjustLaterLink.addEventListener('click', () => {
            showScreen('dashboard-intro-screen');
        });
    }
}

// Dashboard Intro Screen Setup
function setupDashboardIntroScreen() {
    const letsBeginBtn = document.getElementById('lets-begin-btn');
    const takeTourLink = document.getElementById('take-tour-link');
    
    if (letsBeginBtn) {
        letsBeginBtn.addEventListener('click', () => {
            showScreen('dashboard-screen');
        });
    }
    
    if (takeTourLink) {
        takeTourLink.addEventListener('click', () => {
            // In a real app, this would start a guided tour
            alert('Guided tour would be implemented here.');
        });
    }
}

// Dashboard Screen Setup
function setupDashboardScreen() {
    const tabs = document.querySelectorAll('.dashboard-tabs .tab');
    const celebrateBtn = document.getElementById('celebrate-btn');
    const achievementsBtn = document.getElementById('achievements-btn');
    const focusModeBtn = document.getElementById('focus-mode-btn');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            
            // Update active tab
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Show corresponding panel
            document.querySelectorAll('.dashboard-panels .panel').forEach(panel => {
                panel.classList.remove('active');
            });
            document.getElementById(`${tabId}-panel`).classList.add('active');
        });
    });
    
    if (celebrateBtn) {
        celebrateBtn.addEventListener('click', () => {
            // In a real app, this would show a celebration animation
            alert('Celebration animation would be implemented here.');
        });
    }
    
    if (achievementsBtn) {
        achievementsBtn.addEventListener('click', () => {
            // In a real app, this would navigate to achievements screen
            alert('Achievements screen would be implemented here.');
        });
    }
    
    if (focusModeBtn) {
        focusModeBtn.addEventListener('click', () => {
            showScreen('focus-mode-screen');
        });
    }
}

// Tools Screen Setup
function setupToolsScreen() {
    const focusModeCard = document.getElementById('focus-mode-card');
    const intentionSetterCard = document.getElementById('intention-setter-card');
    const mindfulBreakCard = document.getElementById('mindful-break-card');
    const usageAwarenessCard = document.getElementById('usage-awareness-card');
    const sleepImprovementCard = document.getElementById('sleep-improvement-card');
    
    if (focusModeCard) {
        focusModeCard.addEventListener('click', () => {
            showScreen('focus-mode-screen');
        });
    }
    
    if (intentionSetterCard) {
        intentionSetterCard.addEventListener('click', () => {
            // In a real app, this would navigate to intention setter screen
            alert('Intention Setter screen would be implemented here.');
        });
    }
    
    if (mindfulBreakCard) {
        mindfulBreakCard.addEventListener('click', () => {
            // In a real app, this would navigate to mindful break screen
            alert('Mindful Break screen would be implemented here.');
        });
    }
    
    if (usageAwarenessCard) {
        usageAwarenessCard.addEventListener('click', () => {
            // In a real app, this would navigate to usage awareness screen
            alert('Usage Awareness screen would be implemented here.');
        });
    }
    
    if (sleepImprovementCard) {
        sleepImprovementCard.addEventListener('click', () => {
            // In a real app, this would navigate to sleep improvement screen
            alert('Sleep Improvement screen would be implemented here.');
        });
    }
}

// Focus Mode Screen Setup
function setupFocusModeScreen() {
    const optionCards = document.querySelectorAll('.option-card');
    const toggles = document.querySelectorAll('.toggle');
    const startFocusBtn = document.getElementById('start-focus-btn');
    const scheduleLaterLink = document.getElementById('schedule-later-link');
    
    optionCards.forEach(card => {
        card.addEventListener('click', () => {
            optionCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            
            // Update timer display based on selected option
            const timerDisplay = document.querySelector('.timer-display');
            if (timerDisplay) {
                if (card.querySelector('.option-label').textContent === 'Quick Focus') {
                    timerDisplay.textContent = '25:00';
                } else if (card.querySelector('.option-label').textContent === 'Standard Focus') {
                    timerDisplay.textContent = '50:00';
                } else if (card.querySelector('.option-label').textContent === 'Deep Focus') {
                    timerDisplay.textContent = '90:00';
                }
            }
        });
    });
    
    toggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
        });
    });
    
    if (startFocusBtn) {
        startFocusBtn.addEventListener('click', () => {
            // In a real app, this would start the focus timer
            alert('Focus timer would start here. For this prototype, we\'ll return to the dashboard.');
            showScreen('dashboard-screen');
        });
    }
    
    if (scheduleLaterLink) {
        scheduleLaterLink.addEventListener('click', () => {
            // In a real app, this would show a scheduling interface
            alert('Focus session scheduling would be implemented here.');
        });
    }
}
