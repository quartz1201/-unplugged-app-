// Plans Screen Template
const plansScreenTemplate = `
<div class="screen plans-screen">
  <div class="plans-content">
    <h1>Digital Detox Plans</h1>
    <div class="plans-intro">
      <p>Choose a plan that fits your digital wellbeing goals</p>
    </div>
    <div class="plans-container">
      <div class="plan-card">
        <div class="plan-header">
          <div class="plan-icon">🌱</div>
          <div class="plan-title">Beginner Detox</div>
          <div class="plan-difficulty">Easy</div>
        </div>
        <div class="plan-description">
          <p>A gentle introduction to digital mindfulness with small, achievable goals.</p>
        </div>
        <div class="plan-details">
          <div class="plan-detail">
            <div class="detail-label">Duration:</div>
            <div class="detail-value">7 days</div>
          </div>
          <div class="plan-detail">
            <div class="detail-label">Time Commitment:</div>
            <div class="detail-value">15 min/day</div>
          </div>
        </div>
        <button class="plan-action-btn">Start Plan</button>
      </div>
      
      <div class="plan-card">
        <div class="plan-header">
          <div class="plan-icon">🌿</div>
          <div class="plan-title">Balanced Life</div>
          <div class="plan-difficulty">Medium</div>
        </div>
        <div class="plan-description">
          <p>Create sustainable digital habits with a focus on work-life balance.</p>
        </div>
        <div class="plan-details">
          <div class="plan-detail">
            <div class="detail-label">Duration:</div>
            <div class="detail-value">14 days</div>
          </div>
          <div class="plan-detail">
            <div class="detail-label">Time Commitment:</div>
            <div class="detail-value">30 min/day</div>
          </div>
        </div>
        <button class="plan-action-btn">Start Plan</button>
      </div>
      
      <div class="plan-card">
        <div class="plan-header">
          <div class="plan-icon">🌳</div>
          <div class="plan-title">Digital Minimalist</div>
          <div class="plan-difficulty">Advanced</div>
        </div>
        <div class="plan-description">
          <p>Transform your relationship with technology through deep intentionality.</p>
        </div>
        <div class="plan-details">
          <div class="plan-detail">
            <div class="detail-label">Duration:</div>
            <div class="detail-value">30 days</div>
          </div>
          <div class="plan-detail">
            <div class="detail-label">Time Commitment:</div>
            <div class="detail-value">45 min/day</div>
          </div>
        </div>
        <button class="plan-action-btn">Start Plan</button>
      </div>
      
      <div class="plan-card custom">
        <div class="plan-header">
          <div class="plan-icon">✨</div>
          <div class="plan-title">Custom Plan</div>
        </div>
        <div class="plan-description">
          <p>Create your own personalized digital wellbeing plan.</p>
        </div>
        <button class="plan-action-btn">Create Custom Plan</button>
      </div>
    </div>
    
    <div class="active-plans-section">
      <h2>Your Active Plans</h2>
      <div class="active-plan">
        <div class="active-plan-info">
          <div class="active-plan-title">Beginner Detox</div>
          <div class="active-plan-progress">Day 3 of 7</div>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: 42%"></div>
        </div>
        <button class="active-plan-btn">Continue</button>
      </div>
    </div>
  </div>
</div>
`;

// Community Screen Template
const communityScreenTemplate = `
<div class="screen community-screen">
  <div class="community-content">
    <h1>Community</h1>
    <div class="community-intro">
      <p>Connect with others on their digital wellbeing journey</p>
    </div>
    
    <div class="community-tabs">
      <div class="community-tab active" data-tab="challenges">Challenges</div>
      <div class="community-tab" data-tab="discussions">Discussions</div>
      <div class="community-tab" data-tab="success-stories">Success Stories</div>
    </div>
    
    <div class="community-panels">
      <div id="challenges-panel" class="community-panel active">
        <div class="challenge-card">
          <div class="challenge-header">
            <div class="challenge-icon">🌄</div>
            <div class="challenge-title">Morning Mindfulness</div>
          </div>
          <div class="challenge-description">
            <p>Start your day without checking your phone for the first hour.</p>
          </div>
          <div class="challenge-stats">
            <div class="stat">
              <div class="stat-value">328</div>
              <div class="stat-label">Participants</div>
            </div>
            <div class="stat">
              <div class="stat-value">7</div>
              <div class="stat-label">Days</div>
            </div>
            <div class="stat">
              <div class="stat-value">68%</div>
              <div class="stat-label">Success Rate</div>
            </div>
          </div>
          <button class="challenge-join-btn">Join Challenge</button>
        </div>
        
        <div class="challenge-card">
          <div class="challenge-header">
            <div class="challenge-icon">🍽️</div>
            <div class="challenge-title">Phone-Free Meals</div>
          </div>
          <div class="challenge-description">
            <p>Keep your phone away during all meals for more mindful eating.</p>
          </div>
          <div class="challenge-stats">
            <div class="stat">
              <div class="stat-value">512</div>
              <div class="stat-label">Participants</div>
            </div>
            <div class="stat">
              <div class="stat-value">14</div>
              <div class="stat-label">Days</div>
            </div>
            <div class="stat">
              <div class="stat-value">75%</div>
              <div class="stat-label">Success Rate</div>
            </div>
          </div>
          <button class="challenge-join-btn">Join Challenge</button>
        </div>
        
        <div class="challenge-card">
          <div class="challenge-header">
            <div class="challenge-icon">📚</div>
            <div class="challenge-title">Digital Sabbath</div>
          </div>
          <div class="challenge-description">
            <p>Go completely offline for one day each week.</p>
          </div>
          <div class="challenge-stats">
            <div class="stat">
              <div class="stat-value">246</div>
              <div class="stat-label">Participants</div>
            </div>
            <div class="stat">
              <div class="stat-value">30</div>
              <div class="stat-label">Days</div>
            </div>
            <div class="stat">
              <div class="stat-value">52%</div>
              <div class="stat-label">Success Rate</div>
            </div>
          </div>
          <button class="challenge-join-btn">Join Challenge</button>
        </div>
      </div>
      
      <div id="discussions-panel" class="community-panel">
        <div class="discussion-card">
          <div class="discussion-header">
            <div class="user-avatar">JD</div>
            <div class="user-name">Jane Doe</div>
            <div class="post-time">2 hours ago</div>
          </div>
          <div class="discussion-content">
            <p>What strategies have helped you reduce social media usage? I'm finding it particularly challenging in the evenings.</p>
          </div>
          <div class="discussion-stats">
            <div class="stat">
              <div class="stat-value">24</div>
              <div class="stat-label">Replies</div>
            </div>
            <div class="stat">
              <div class="stat-value">42</div>
              <div class="stat-label">Likes</div>
            </div>
          </div>
          <button class="discussion-reply-btn">Reply</button>
        </div>
        
        <div class="discussion-card">
          <div class="discussion-header">
            <div class="user-avatar">MS</div>
            <div class="user-name">Mark Smith</div>
            <div class="post-time">Yesterday</div>
          </div>
          <div class="discussion-content">
            <p>I've been using the Focus Mode for a week now and it's completely changed my work productivity. Anyone else experiencing similar benefits?</p>
          </div>
          <div class="discussion-stats">
            <div class="stat">
              <div class="stat-value">18</div>
              <div class="stat-label">Replies</div>
            </div>
            <div class="stat">
              <div class="stat-value">36</div>
              <div class="stat-label">Likes</div>
            </div>
          </div>
          <button class="discussion-reply-btn">Reply</button>
        </div>
      </div>
      
      <div id="success-stories-panel" class="community-panel">
        <div class="story-card">
          <div class="story-header">
            <div class="user-avatar">AJ</div>
            <div class="user-name">Alex Johnson</div>
          </div>
          <div class="story-title">From 6 Hours to 2: My Digital Transformation</div>
          <div class="story-content">
            <p>Three months ago, I was spending over 6 hours daily on my phone. Using the Unplugged app's progressive detox plan, I've reduced that to just 2 hours of intentional usage...</p>
          </div>
          <button class="story-read-more-btn">Read More</button>
          <div class="story-stats">
            <div class="stat">
              <div class="stat-value">128</div>
              <div class="stat-label">Inspired</div>
            </div>
          </div>
        </div>
        
        <div class="story-card">
          <div class="story-header">
            <div class="user-avatar">LP</div>
            <div class="user-name">Lisa Park</div>
          </div>
          <div class="story-title">How Digital Minimalism Improved My Sleep</div>
          <div class="story-content">
            <p>I used to struggle with insomnia, largely due to late-night scrolling. After following the Sleep Improvement recommendations in the app, I now sleep 7+ hours nightly...</p>
          </div>
          <button class="story-read-more-btn">Read More</button>
          <div class="story-stats">
            <div class="stat">
              <div class="stat-value">95</div>
              <div class="stat-label">Inspired</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
`;

// Add CSS for Plans and Community screens
const additionalStyles = `
/* Plans Screen Styles */
.plans-screen {
  padding: 60px 20px 20px;
}

.plans-content {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.plans-intro {
  margin-bottom: 20px;
}

.plans-container {
  display: flex;
  flex-direction: column;
  gap: 15px;
  margin-bottom: 30px;
}

.plan-card {
  background-color: var(--bg-color);
  border-radius: 15px;
  padding: 15px;
  box-shadow: 0 2px 10px var(--shadow-color);
}

.plan-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.plan-icon {
  font-size: 24px;
  margin-right: 10px;
}

.plan-title {
  font-size: 18px;
  font-weight: bold;
  flex: 1;
}

.plan-difficulty {
  font-size: 14px;
  padding: 4px 8px;
  border-radius: 10px;
  background-color: var(--accent-light);
  color: var(--accent-color);
}

.plan-description {
  margin-bottom: 15px;
  font-size: 14px;
  color: var(--text-secondary);
}

.plan-details {
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin-bottom: 15px;
}

.plan-detail {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
}

.detail-label {
  color: var(--text-secondary);
}

.plan-action-btn {
  width: 100%;
  padding: 12px;
  background-color: var(--accent-color);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 16px;
  cursor: pointer;
}

.plan-card.custom {
  border: 2px dashed var(--border-color);
  background-color: transparent;
}

.active-plans-section {
  margin-top: 20px;
}

.active-plan {
  background-color: var(--bg-color);
  border-radius: 15px;
  padding: 15px;
  margin-top: 10px;
}

.active-plan-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}

.active-plan-title {
  font-weight: bold;
}

.progress-bar {
  height: 8px;
  background-color: var(--border-color);
  border-radius: 4px;
  margin-bottom: 15px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background-color: var(--accent-color);
  border-radius: 4px;
}

.active-plan-btn {
  width: 100%;
  padding: 10px;
  background-color: var(--accent-color);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 14px;
  cursor: pointer;
}

/* Community Screen Styles */
.community-screen {
  padding: 60px 20px 20px;
}

.community-content {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.community-intro {
  margin-bottom: 20px;
}

.community-tabs {
  display: flex;
  border-bottom: 1px solid var(--border-color);
  margin-bottom: 20px;
}

.community-tab {
  padding: 10px 15px;
  font-size: 16px;
  cursor: pointer;
  position: relative;
}

.community-tab.active {
  color: var(--accent-color);
}

.community-tab.active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  width: 100%;
  height: 2px;
  background-color: var(--accent-color);
}

.community-panel {
  display: none;
  flex-direction: column;
  gap: 15px;
}

.community-panel.active {
  display: flex;
}

.challenge-card, .discussion-card, .story-card {
  background-color: var(--bg-color);
  border-radius: 15px;
  padding: 15px;
  margin-bottom: 15px;
  box-shadow: 0 2px 10px var(--shadow-color);
}

.challenge-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.challenge-icon {
  font-size: 24px;
  margin-right: 10px;
}

.challenge-title {
  font-size: 18px;
  font-weight: bold;
}

.challenge-description {
  margin-bottom: 15px;
  font-size: 14px;
  color: var(--text-secondary);
}

.challenge-stats {
  display: flex;
  justify-content: space-around;
  margin-bottom: 15px;
}

.stat {
  text-align: center;
}

.stat-value {
  font-size: 18px;
  font-weight: bold;
}

.stat-label {
  font-size: 12px;
  color: var(--text-secondary);
}

.challenge-join-btn, .discussion-reply-btn, .story-read-more-btn {
  width: 100%;
  padding: 10px;
  background-color: var(--accent-color);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 14px;
  cursor: pointer;
}

.discussion-header, .story-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.user-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: var(--accent-light);
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  font-weight: bold;
  color: var(--accent-color);
}

.user-name {
  font-weight: bold;
  flex: 1;
}

.post-time {
  font-size: 12px;
  color: var(--text-secondary);
}

.discussion-content, .story-content {
  margin-bottom: 15px;
  font-size: 14px;
}

.story-title {
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 10px;
}

.discussion-stats {
  display: flex;
  gap: 15px;
  margin-bottom: 15px;
}

.story-stats {
  margin-top: 10px;
}
`;

// Add JavaScript for Plans and Community functionality
const additionalScripts = `
// Handle Plans and Community navigation
function initializeAdditionalScreens() {
  // Register Plans screen
  screenTemplates['plans-screen'] = plansScreenTemplate;
  
  // Register Community screen
  screenTemplates['community-screen'] = communityScreenTemplate;
  
  // Add event listeners for Plans screen
  document.addEventListener('click', function(e) {
    // Plan action buttons
    if (e.target.classList.contains('plan-action-btn')) {
      showToast('Plan selected! Starting your digital wellbeing journey.');
    }
    
    // Active plan continue button
    if (e.target.classList.contains('active-plan-btn')) {
      showToast('Continuing with your active plan.');
    }
  });
  
  // Add event listeners for Community screen
  document.addEventListener('click', function(e) {
    // Community tabs
    if (e.target.classList.contains('community-tab')) {
      const tabName = e.target.getAttribute('data-tab');
      
      // Update active tab
      document.querySelectorAll('.community-tab').forEach(tab => {
        tab.classList.remove('active');
      });
      e.target.classList.add('active');
      
      // Show corresponding panel
      document.querySelectorAll('.community-panel').forEach(panel => {
        panel.classList.remove('active');
      });
      document.getElementById(tabName + '-panel').classList.add('active');
    }
    
    // Challenge join button
    if (e.target.classList.contains('challenge-join-btn')) {
      showToast('You\'ve joined the challenge! Check your active challenges.');
    }
    
    // Discussion reply button
    if (e.target.classList.contains('discussion-reply-btn')) {
      showToast('Reply feature coming soon!');
    }
    
    // Story read more button
    if (e.target.classList.contains('story-read-more-btn')) {
      showToast('Full story coming soon!');
    }
  });
}

// Call this function after the main initialization
document.addEventListener('DOMContentLoaded', function() {
  // This will be called by the enhanced script's init function
});
`;

// Export the new components
window.plansScreenTemplate = plansScreenTemplate;
window.communityScreenTemplate = communityScreenTemplate;
window.additionalStyles = additionalStyles;
window.additionalScripts = additionalScripts;
window.initializeAdditionalScreens = initializeAdditionalScreens;
