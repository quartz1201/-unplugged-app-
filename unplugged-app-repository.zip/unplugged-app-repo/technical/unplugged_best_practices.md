# Unplugged App: Development Best Practices Guide

## Introduction

This guide outlines the recommended best practices for developing the Unplugged app. As your first app development project, following these guidelines will help ensure high-quality code, efficient development processes, and a successful product. The practices are organized by development area and include practical examples where applicable.

## Table of Contents

1. [Code Quality & Standards](#code-quality--standards)
2. [Architecture & Design Patterns](#architecture--design-patterns)
3. [Performance Optimization](#performance-optimization)
4. [Security Best Practices](#security-best-practices)
5. [Testing Strategies](#testing-strategies)
6. [Version Control & Collaboration](#version-control--collaboration)
7. [Accessibility Guidelines](#accessibility-guidelines)
8. [Cross-Platform Considerations](#cross-platform-considerations)
9. [Documentation Standards](#documentation-standards)
10. [DevOps & Deployment](#devops--deployment)

## Code Quality & Standards

### Coding Style & Formatting

**Use consistent formatting with automated tools:**
- Configure ESLint and Prettier for automatic code formatting
- Create a `.eslintrc` and `.prettierrc` at the project root
- Enforce formatting on pre-commit hooks

**Example ESLint configuration:**
```json
{
  "extends": [
    "eslint:recommended",
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
    "plugin:@typescript-eslint/recommended"
  ],
  "parser": "@typescript-eslint/parser",
  "plugins": ["react", "react-hooks", "@typescript-eslint"],
  "rules": {
    "no-console": ["warn", { "allow": ["warn", "error"] }],
    "react-hooks/rules-of-hooks": "error",
    "react-hooks/exhaustive-deps": "warn",
    "@typescript-eslint/explicit-function-return-type": "off",
    "@typescript-eslint/no-unused-vars": ["error", { "argsIgnorePattern": "^_" }]
  }
}
```

### TypeScript Usage

**Leverage TypeScript for type safety:**
- Define interfaces for all data models
- Use type annotations for function parameters and return types
- Avoid using `any` type; use proper type definitions or generics

**Example data model with TypeScript:**
```typescript
interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
  preferences: UserPreferences;
  digitalScore: number;
}

interface UserPreferences {
  notifications: {
    dailySummary: boolean;
    goalReminders: boolean;
    focusMode: boolean;
  };
  theme: 'light' | 'dark' | 'system';
  privacySettings: {
    shareUsageData: boolean;
    participateInCommunity: boolean;
  };
}
```

### Code Organization

**Follow a consistent project structure:**
- Group files by feature rather than by type
- Keep related files close to each other
- Use index files to simplify imports

**Recommended project structure:**
```
src/
├── app/                  # App initialization
├── features/             # Feature modules
│   ├── authentication/   # Authentication feature
│   ├── dashboard/        # Dashboard feature
│   ├── focus-mode/       # Focus mode feature
│   └── ...
├── components/           # Shared components
├── hooks/                # Custom hooks
├── navigation/           # Navigation configuration
├── services/             # API and other services
├── store/                # State management
├── theme/                # Styling and theming
└── utils/                # Utility functions
```

### Naming Conventions

**Use clear, descriptive names:**
- Components: PascalCase (e.g., `FocusModeTimer.tsx`)
- Functions and variables: camelCase (e.g., `calculateDigitalScore`)
- Constants: UPPER_SNAKE_CASE (e.g., `MAX_SESSION_DURATION`)
- Files: kebab-case for files, PascalCase for component files

**Example naming in practice:**
```typescript
// Constants
const DEFAULT_FOCUS_DURATION = 25; // minutes
const MAX_FOCUS_DURATION = 120; // minutes

// Component
function FocusModeTimer({ initialDuration, onComplete }: FocusModeTimerProps) {
  // Variables
  const [remainingTime, setRemainingTime] = useState(initialDuration);
  
  // Functions
  function startCountdown() {
    // Implementation
  }
  
  return (
    // JSX
  );
}
```

## Architecture & Design Patterns

### Component Architecture

**Follow component composition patterns:**
- Create small, focused components with single responsibilities
- Use composition over inheritance
- Implement container/presentational pattern for complex components

**Example component composition:**
```tsx
// Presentational component
function FocusTimer({ duration, isActive, onComplete }: FocusTimerProps) {
  return (
    <View style={styles.timerContainer}>
      <TimerDisplay time={duration} />
      <TimerProgress percentage={calculatePercentage(duration)} />
    </View>
  );
}

// Container component
function FocusModeContainer() {
  const [duration, setDuration] = useState(25 * 60); // 25 minutes in seconds
  const [isActive, setIsActive] = useState(false);
  
  function handleComplete() {
    // Handle timer completion
  }
  
  return (
    <View style={styles.container}>
      <FocusTimer 
        duration={duration} 
        isActive={isActive} 
        onComplete={handleComplete} 
      />
      <FocusControls 
        onStart={() => setIsActive(true)} 
        onPause={() => setIsActive(false)} 
      />
    </View>
  );
}
```

### State Management

**Implement appropriate state management based on complexity:**
- Use React Context for theme, authentication, and app-wide settings
- Consider Redux for complex state with many interactions
- Use local state for component-specific state

**Example React Context implementation:**
```tsx
// Create context
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Provider component
function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  
  const toggleTheme = useCallback(() => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  }, []);
  
  const value = { theme, toggleTheme };
  
  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
}

// Custom hook for using the context
function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
```

### Custom Hooks

**Extract reusable logic into custom hooks:**
- Create hooks for common patterns and behaviors
- Follow the "use" prefix naming convention
- Keep hooks focused on a single concern

**Example custom hook:**
```typescript
function useFocusSession(initialDuration: number) {
  const [duration, setDuration] = useState(initialDuration);
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isActive && !isPaused) {
      interval = setInterval(() => {
        setElapsedTime(prev => {
          const newElapsed = prev + 1;
          if (newElapsed >= duration) {
            clearInterval(interval);
            setIsActive(false);
            return duration;
          }
          return newElapsed;
        });
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isActive, isPaused, duration]);
  
  const start = useCallback(() => {
    setIsActive(true);
    setIsPaused(false);
  }, []);
  
  const pause = useCallback(() => {
    setIsPaused(true);
  }, []);
  
  const resume = useCallback(() => {
    setIsPaused(false);
  }, []);
  
  const reset = useCallback(() => {
    setIsActive(false);
    setIsPaused(false);
    setElapsedTime(0);
  }, []);
  
  return {
    elapsedTime,
    remainingTime: duration - elapsedTime,
    progress: elapsedTime / duration,
    isActive,
    isPaused,
    start,
    pause,
    resume,
    reset
  };
}
```

## Performance Optimization

### React Native Optimization

**Minimize re-renders:**
- Use `React.memo` for components that render often but rarely change
- Implement `useCallback` for function props
- Use `useMemo` for expensive calculations

**Example optimization:**
```tsx
// Memoize component to prevent unnecessary re-renders
const UsageChart = React.memo(({ data, period }: UsageChartProps) => {
  // Component implementation
});

function DashboardScreen() {
  const [period, setPeriod] = useState<'day' | 'week' | 'month'>('day');
  const [usageData, setUsageData] = useState<UsageData[]>([]);
  
  // Memoize callback to prevent recreation on each render
  const handlePeriodChange = useCallback((newPeriod: 'day' | 'week' | 'month') => {
    setPeriod(newPeriod);
  }, []);
  
  // Memoize expensive calculation
  const processedData = useMemo(() => {
    return processUsageData(usageData, period);
  }, [usageData, period]);
  
  return (
    <View>
      <PeriodSelector period={period} onChange={handlePeriodChange} />
      <UsageChart data={processedData} period={period} />
    </View>
  );
}
```

### Image Optimization

**Optimize images for mobile:**
- Use appropriate image formats (PNG for transparency, JPEG for photos)
- Implement responsive images with different resolutions
- Use image caching for frequently accessed images

**Example image optimization:**
```tsx
import FastImage from 'react-native-fast-image';

function OptimizedImage({ uri, style }: { uri: string, style?: StyleProp<ImageStyle> }) {
  return (
    <FastImage
      style={style}
      source={{
        uri: uri,
        priority: FastImage.priority.normal,
        cache: FastImage.cacheControl.immutable
      }}
      resizeMode={FastImage.resizeMode.cover}
    />
  );
}
```

### List Rendering

**Optimize list performance:**
- Use `FlatList` or `SectionList` instead of mapping arrays to components
- Implement proper key extraction
- Use `getItemLayout` when item dimensions are known
- Implement list item recycling with `PureComponent` or `memo`

**Example optimized list:**
```tsx
function OptimizedList({ items }: { items: ListItem[] }) {
  const renderItem = useCallback(({ item }: { item: ListItem }) => (
    <ListItemComponent item={item} />
  ), []);
  
  const keyExtractor = useCallback((item: ListItem) => item.id, []);
  
  const getItemLayout = useCallback(
    (_: any, index: number) => ({
      length: 80, // fixed height for each item
      offset: 80 * index,
      index,
    }),
    []
  );
  
  return (
    <FlatList
      data={items}
      renderItem={renderItem}
      keyExtractor={keyExtractor}
      getItemLayout={getItemLayout}
      initialNumToRender={10}
      maxToRenderPerBatch={10}
      windowSize={5}
      removeClippedSubviews={true}
    />
  );
}
```

## Security Best Practices

### Authentication

**Implement secure authentication:**
- Use Firebase Authentication or other trusted authentication providers
- Store authentication tokens securely
- Implement token refresh mechanisms
- Use biometric authentication when available

**Example secure token storage:**
```typescript
import * as SecureStore from 'expo-secure-store';

async function storeAuthToken(token: string): Promise<void> {
  await SecureStore.setItemAsync('auth_token', token);
}

async function getAuthToken(): Promise<string | null> {
  return await SecureStore.getItemAsync('auth_token');
}

async function removeAuthToken(): Promise<void> {
  await SecureStore.deleteItemAsync('auth_token');
}
```

### Data Protection

**Protect sensitive user data:**
- Encrypt sensitive data before storing locally
- Implement proper data validation
- Use HTTPS for all API requests
- Implement certificate pinning for critical API endpoints

**Example data encryption:**
```typescript
import * as Crypto from 'expo-crypto';

async function encryptData(data: string, key: string): Promise<string> {
  const iv = Crypto.getRandomBytes(16);
  const cipher = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    data + key + iv.toString('hex')
  );
  return JSON.stringify({
    cipher,
    iv: iv.toString('hex')
  });
}

async function decryptData(encryptedData: string, key: string): Promise<string | null> {
  try {
    const { cipher, iv } = JSON.parse(encryptedData);
    // Implementation would depend on the encryption method used
    // This is a simplified example
    return decryptedData;
  } catch (error) {
    console.error('Failed to decrypt data:', error);
    return null;
  }
}
```

### Input Validation

**Validate all user inputs:**
- Implement client-side validation for immediate feedback
- Always validate on the server side as well
- Use validation libraries like Yup or Zod
- Sanitize inputs to prevent injection attacks

**Example input validation:**
```typescript
import * as yup from 'yup';

// Define validation schema
const goalSchema = yup.object().shape({
  title: yup.string().required('Title is required').max(100, 'Title is too long'),
  targetValue: yup.number().positive('Must be positive').required('Target is required'),
  duration: yup.number().min(1, 'Duration must be at least 1 day').required('Duration is required'),
  category: yup.string().oneOf(['screenTime', 'focus', 'mindfulness', 'sleep'], 'Invalid category')
});

// Validate input
async function validateGoalInput(goalData: unknown): Promise<boolean> {
  try {
    await goalSchema.validate(goalData);
    return true;
  } catch (error) {
    if (error instanceof yup.ValidationError) {
      // Handle validation error
      console.error('Validation error:', error.message);
    }
    return false;
  }
}
```

## Testing Strategies

### Unit Testing

**Write comprehensive unit tests:**
- Test individual functions and components in isolation
- Use Jest as the testing framework
- Mock dependencies and external services
- Aim for high test coverage of business logic

**Example unit test:**
```typescript
import { calculateDigitalScore } from '../utils/scoreCalculator';

describe('calculateDigitalScore', () => {
  test('returns 100 for perfect usage patterns', () => {
    const usageData = {
      screenTime: 60, // 1 hour
      pickups: 10,
      focusSessionsCompleted: 3,
      goalProgress: 100
    };
    
    expect(calculateDigitalScore(usageData)).toBe(100);
  });
  
  test('returns lower score for excessive usage', () => {
    const usageData = {
      screenTime: 360, // 6 hours
      pickups: 50,
      focusSessionsCompleted: 0,
      goalProgress: 20
    };
    
    const score = calculateDigitalScore(usageData);
    expect(score).toBeLessThan(50);
  });
  
  test('handles missing data gracefully', () => {
    const usageData = {
      screenTime: 120,
      pickups: undefined,
      focusSessionsCompleted: 1,
      goalProgress: 60
    };
    
    expect(() => calculateDigitalScore(usageData)).not.toThrow();
    expect(calculateDigitalScore(usageData)).toBeGreaterThan(0);
  });
});
```

### Component Testing

**Test React components:**
- Use React Testing Library for component tests
- Focus on testing behavior, not implementation details
- Write tests from the user's perspective
- Test accessibility features

**Example component test:**
```typescript
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import FocusModeTimer from '../components/FocusModeTimer';

describe('FocusModeTimer', () => {
  test('renders correctly with initial duration', () => {
    const { getByText } = render(
      <FocusModeTimer initialDuration={25} onComplete={jest.fn()} />
    );
    
    expect(getByText('25:00')).toBeTruthy();
  });
  
  test('starts countdown when start button is pressed', async () => {
    const { getByText } = render(
      <FocusModeTimer initialDuration={25} onComplete={jest.fn()} />
    );
    
    fireEvent.press(getByText('Start'));
    
    // Wait for timer to update
    await waitFor(() => {
      expect(getByText('24:59')).toBeTruthy();
    }, { timeout: 2000 });
  });
  
  test('calls onComplete when timer finishes', async () => {
    jest.useFakeTimers();
    const onComplete = jest.fn();
    
    const { getByText } = render(
      <FocusModeTimer initialDuration={1/60} onComplete={onComplete} />
    );
    
    fireEvent.press(getByText('Start'));
    
    // Fast-forward timer
    jest.advanceTimersByTime(1000);
    
    expect(onComplete).toHaveBeenCalled();
    jest.useRealTimers();
  });
});
```

### End-to-End Testing

**Implement end-to-end tests for critical flows:**
- Use Detox for React Native end-to-end testing
- Test complete user journeys
- Focus on critical paths like onboarding and core features
- Run E2E tests on CI/CD pipeline before deployment

**Example E2E test configuration:**
```javascript
// e2e/jest.config.js
module.exports = {
  preset: 'jest-expo',
  testMatch: ['**/?(*.)+(e2e).[jt]s?(x)'],
  setupFilesAfterEnv: ['./jest.setup.js'],
};

// e2e/jest.setup.js
import { cleanup } from '@testing-library/react-native';
import { device, element, by } from 'detox';

beforeAll(async () => {
  await device.launchApp();
});

afterAll(async () => {
  await cleanup();
});

// e2e/onboarding.e2e.js
describe('Onboarding Flow', () => {
  beforeAll(async () => {
    await device.reloadReactNative();
  });

  it('should complete onboarding successfully', async () => {
    // Welcome screen
    await expect(element(by.text('Unplugged'))).toBeVisible();
    await element(by.text('Get Started')).tap();
    
    // Assessment screen 1
    await expect(element(by.text('Digital Habits Assessment'))).toBeVisible();
    await element(by.text('2-4 hours')).tap();
    await element(by.text('Next')).tap();
    
    // Assessment screen 2
    await element(by.text('Reduce overall screen time')).tap();
    await element(by.text('Next')).tap();
    
    // Assessment screen 3
    await element(by.text('Improve focus and productivity')).tap();
    await element(by.text('Complete')).tap();
    
    // Goal setting screen
    await expect(element(by.text('Set Your Goals'))).toBeVisible();
    await element(by.text('Set Goals')).tap();
    
    // Dashboard intro screen
    await expect(element(by.text('Your Dashboard'))).toBeVisible();
    await element(by.text('Let\'s Begin')).tap();
    
    // Dashboard screen
    await expect(element(by.text('Digital Wellbeing Score'))).toBeVisible();
  });
});
```

## Version Control & Collaboration

### Git Workflow

**Implement a structured Git workflow:**
- Use feature branches for all new development
- Create pull requests for code review
- Enforce branch protection on main branches
- Use semantic versioning for releases

**Recommended Git workflow:**
```bash
# Start a new feature
git checkout develop
git pull
git checkout -b feature/focus-mode-timer

# Make changes and commit
git add .
git commit -m "feat: implement focus mode timer component"

# Push changes and create pull request
git push -u origin feature/focus-mode-timer

# After PR is approved, merge to develop
git checkout develop
git pull
git merge --no-ff feature/focus-mode-timer
git push

# For releases
git checkout main
git pull
git merge --no-ff develop
git tag -a v1.0.0 -m "Version 1.0.0"
git push --tags
```

### Commit Messages

**Use conventional commit messages:**
- Follow the Conventional Commits specification
- Use types like feat, fix, docs, style, refactor, test, chore
- Write clear, descriptive commit messages
- Reference issue numbers when applicable

**Example commit messages:**
```
feat(focus-mode): implement countdown timer with pause functionality

fix(auth): resolve token refresh issue on app restart

docs: update README with setup instructions

refactor(dashboard): improve performance of usage charts

test(goals): add unit tests for goal progress calculation

chore: update dependencies to latest versions
```

### Code Reviews

**Conduct thorough code reviews:**
- Use pull request templates to standardize information
- Define clear review criteria
- Automate checks for linting, tests, and type checking
- Require at least one approval before merging

**Example pull request template:**
```markdown
## Description
[Describe the changes and the problem they solve]

## Type of change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## How Has This Been Tested?
- [ ] Unit tests
- [ ] Integration tests
- [ ] Manual testing

## Checklist:
- [ ] My code follows the style guidelines of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
```

## Accessibility Guidelines

### Screen Reader Support

**Ensure screen reader compatibility:**
- Use proper accessibility labels for all interactive elements
- Implement semantic heading structure
- Ensure focus order is logical
- Test with VoiceOver (iOS) and TalkBack (Android)

**Example accessibility implementation:**
```tsx
function AccessibleButton({ onPress, label, hint }: AccessibleButtonProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      accessible={true}
      accessibilityLabel={label}
      accessibilityHint={hint}
      accessibilityRole="button"
    >
      <Text style={styles.buttonText}>{label}</Text>
    </TouchableOpacity>
  );
}

// Usage
<AccessibleButton
  onPress={startFocusSession}
  label="Start Focus Session"
  hint="Begins a 25-minute focus session with no distractions"
/>
```

### Color Contrast

**Maintain proper color contrast:**
- Ensure text has sufficient contrast against backgrounds (WCAG AA: 4.5:1 for normal text, 3:1 for large text)
- Don't rely solely on color to convey information
- Test with color blindness simulators
- Provide high contrast mode option

**Example contrast checking utility:**
```typescript
function calculateContrastRatio(foreground: string, background: string): number {
  const getLuminance = (color: string): number => {
    // Convert hex to RGB
    const r = parseInt(color.substr(1, 2), 16) / 255;
    const g = parseInt(color.substr(3, 2), 16) / 255;
    const b = parseInt(color.substr(5, 2), 16) / 255;
    
    // Calculate luminance
    const rgb = [r, g, b].map(c => {
      return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
  };
  
  const foregroundLuminance = getLuminance(foreground);
  const backgroundLuminance = getLuminance(background);
  
  // Calculate contrast ratio
  const ratio = (Math.max(foregroundLuminance, backgroundLuminance) + 0.05) /
                (Math.min(foregroundLuminance, backgroundLuminance) + 0.05);
  
  return parseFloat(ratio.toFixed(2));
}

// Usage
const contrastRatio = calculateContrastRatio('#333333', '#FFFFFF');
console.log(`Contrast ratio: ${contrastRatio}:1`); // Should be at least 4.5:1
```

### Dynamic Text Sizing

**Support dynamic text sizes:**
- Use relative units (not fixed pixel sizes)
- Test with different text size settings
- Ensure layouts adapt to larger text sizes
- Avoid truncating text when size increases

**Example dynamic text implementation:**
```tsx
import { useDynamicTextSize } from '../hooks/useDynamicTextSize';

function DynamicText({ style, children }: TextProps) {
  const { scaledFontSize, lineHeight } = useDynamicTextSize(16); // Base size
  
  return (
    <Text
      style={[
        style,
        {
          fontSize: scaledFontSize,
          lineHeight: lineHeight,
        },
      ]}
      allowFontScaling={true}
      maxFontSizeMultiplier={2}
    >
      {children}
    </Text>
  );
}
```

## Cross-Platform Considerations

### Platform-Specific Code

**Handle platform differences elegantly:**
- Use Platform.OS for simple conditionals
- Create platform-specific files for more complex differences
- Implement platform-specific components when necessary
- Test thoroughly on both iOS and Android

**Example platform-specific implementation:**
```tsx
import { Platform, StyleSheet } from 'react-native';

// Simple conditional
const styles = StyleSheet.create({
  container: {
    elevation: Platform.OS === 'android' ? 4 : 0, // Android shadow
    shadowColor: Platform.OS === 'ios' ? '#000' : 'transparent', // iOS shadow
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
});

// Platform-specific files
// Button.ios.tsx and Button.android.tsx
// Import will automatically choose the correct file
import Button from './Button';

// Platform-specific components
function DatePicker() {
  if (Platform.OS === 'ios') {
    return <IOSDatePicker />;
  }
  return <AndroidDatePicker />;
}
```

### Responsive Design

**Create responsive layouts:**
- Use Flexbox for flexible layouts
- Calculate dimensions based on screen size
- Test on various device sizes and orientations
- Implement adaptive layouts for tablets

**Example responsive layout:**
```tsx
import { Dimensions, StyleSheet } from 'react-native';

const { width, height } = Dimensions.get('window');
const isSmallDevice = width < 375;

const styles = StyleSheet.create({
  container: {
    padding: isSmallDevice ? 10 : 20,
  },
  title: {
    fontSize: isSmallDevice ? 20 : 24,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gridItem: {
    width: width < 600 ? (width - 40) / 2 : (width - 60) / 3,
    marginBottom: 15,
  },
});

// Listen for orientation changes
Dimensions.addEventListener('change', ({ window }) => {
  const { width, height } = window;
  // Update layout based on new dimensions
});
```

### Native Module Integration

**Integrate native functionality carefully:**
- Use well-maintained libraries for native functionality
- Test native features on actual devices, not just simulators
- Implement graceful fallbacks for unsupported features
- Document platform-specific limitations

**Example native module integration:**
```typescript
import { Platform } from 'react-native';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';

async function requestUsageStatsPermission(): Promise<boolean> {
  if (Platform.OS === 'android') {
    try {
      const result = await request(PERMISSIONS.ANDROID.PACKAGE_USAGE_STATS);
      return result === RESULTS.GRANTED;
    } catch (error) {
      console.error('Failed to request usage stats permission:', error);
      return false;
    }
  } else if (Platform.OS === 'ios') {
    // iOS doesn't provide direct access to usage stats
    // Implement alternative approach or inform user about limitation
    return false;
  }
  return false;
}

// Usage with fallback
async function getUsageData() {
  const hasPermission = await requestUsageStatsPermission();
  
  if (hasPermission) {
    // Get actual usage data from native API
    return getNativeUsageData();
  } else {
    // Fallback to user-reported data or alternative approach
    return getAlternativeUsageData();
  }
}
```

## Documentation Standards

### Code Documentation

**Document code thoroughly:**
- Add JSDoc comments for functions and components
- Document parameters, return values, and exceptions
- Include examples for complex functions
- Keep documentation up-to-date with code changes

**Example code documentation:**
```typescript
/**
 * Calculates the digital wellbeing score based on usage patterns.
 * 
 * The score is calculated using a weighted algorithm that considers:
 * - Daily screen time relative to target
 * - Number of phone pickups
 * - Focus sessions completed
 * - Progress toward goals
 * 
 * @param {UsageData} usageData - The user's usage data
 * @param {GoalData} goalData - The user's goal data
 * @returns {number} A score between 0-100, where higher is better
 * @throws {Error} If required data is missing or invalid
 * 
 * @example
 * const score = calculateDigitalScore({
 *   screenTime: 120, // minutes
 *   pickups: 25,
 *   focusSessionsCompleted: 2,
 *   goalProgress: 75
 * });
 */
function calculateDigitalScore(usageData: UsageData, goalData: GoalData): number {
  // Implementation
}
```

### README and Project Documentation

**Maintain comprehensive project documentation:**
- Create a detailed README with setup instructions
- Document architecture decisions and patterns
- Include troubleshooting guides
- Keep documentation in sync with code changes

**Example README structure:**
```markdown
# Unplugged App

A digital wellbeing app focused on mindful technology use.

## Features

- Digital wellbeing score tracking
- Focus mode with app blocking
- Goal setting and tracking
- Personalized insights
- Community challenges

## Getting Started

### Prerequisites

- Node.js 14+
- Yarn or npm
- React Native environment setup
- iOS: XCode 12+
- Android: Android Studio 4+

### Installation

1. Clone the repository
   ```bash
   git clone https://github.com/your-org/unplugged-app.git
   cd unplugged-app
   ```

2. Install dependencies
   ```bash
   yarn install
   ```

3. Install iOS pods
   ```bash
   cd ios && pod install && cd ..
   ```

4. Start the development server
   ```bash
   yarn start
   ```

5. Run on iOS or Android
   ```bash
   yarn ios
   # or
   yarn android
   ```

## Architecture

[Architecture description, diagrams, etc.]

## Development Workflow

[Development process, branching strategy, etc.]

## Testing

[Testing strategy and instructions]

## Deployment

[Deployment process and instructions]

## Contributing

[Contribution guidelines]

## License

[License information]
```

### API Documentation

**Document APIs clearly:**
- Use Swagger or similar tools for API documentation
- Document request/response formats
- Include authentication requirements
- Provide example requests and responses

**Example API documentation:**
```yaml
# swagger.yaml
openapi: 3.0.0
info:
  title: Unplugged API
  version: 1.0.0
  description: API for the Unplugged digital wellbeing app
paths:
  /api/goals:
    get:
      summary: Get user goals
      description: Retrieves all goals for the authenticated user
      security:
        - bearerAuth: []
      responses:
        '200':
          description: A list of user goals
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/Goal'
        '401':
          description: Unauthorized
    post:
      summary: Create a new goal
      description: Creates a new goal for the authenticated user
      security:
        - bearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/GoalInput'
      responses:
        '201':
          description: Goal created successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Goal'
        '400':
          description: Invalid input
        '401':
          description: Unauthorized
components:
  schemas:
    Goal:
      type: object
      properties:
        id:
          type: string
          example: "goal_123456"
        title:
          type: string
          example: "Reduce screen time by 20%"
        targetValue:
          type: number
          example: 20
        currentValue:
          type: number
          example: 15
        progress:
          type: number
          example: 75
        startDate:
          type: string
          format: date-time
        endDate:
          type: string
          format: date-time
    GoalInput:
      type: object
      required:
        - title
        - targetValue
      properties:
        title:
          type: string
          example: "Reduce screen time by 20%"
        targetValue:
          type: number
          example: 20
        duration:
          type: number
          example: 30
        category:
          type: string
          enum: [screenTime, focus, mindfulness, sleep]
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
```

## DevOps & Deployment

### Continuous Integration

**Implement robust CI pipeline:**
- Run linting, type checking, and tests on every pull request
- Enforce code coverage thresholds
- Automate build process for both platforms
- Generate build artifacts for testing

**Example GitHub Actions workflow:**
```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  lint-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
          cache: 'yarn'
      - name: Install dependencies
        run: yarn install --frozen-lockfile
      - name: Lint
        run: yarn lint
      - name: Type check
        run: yarn typescript
      - name: Test
        run: yarn test --coverage
      - name: Upload coverage
        uses: codecov/codecov-action@v2

  build-android:
    needs: lint-and-test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
          cache: 'yarn'
      - name: Install dependencies
        run: yarn install --frozen-lockfile
      - name: Build Android
        run: cd android && ./gradlew assembleRelease
      - name: Upload APK
        uses: actions/upload-artifact@v2
        with:
          name: app-release
          path: android/app/build/outputs/apk/release/app-release.apk

  build-ios:
    needs: lint-and-test
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
          cache: 'yarn'
      - name: Install dependencies
        run: yarn install --frozen-lockfile
      - name: Install CocoaPods
        run: cd ios && pod install
      - name: Build iOS
        run: cd ios && xcodebuild -workspace Unplugged.xcworkspace -scheme Unplugged -configuration Release -sdk iphonesimulator
```

### Environment Configuration

**Manage environment configurations:**
- Use environment variables for configuration
- Create separate configurations for development, staging, and production
- Keep sensitive information out of source control
- Use a secure method for managing secrets

**Example environment configuration:**
```typescript
// config/env.ts
import { Platform } from 'react-native';
import Config from 'react-native-config';

type Environment = 'development' | 'staging' | 'production';

interface EnvConfig {
  API_URL: string;
  FIREBASE_CONFIG: {
    apiKey: string;
    authDomain: string;
    projectId: string;
    storageBucket: string;
    messagingSenderId: string;
    appId: string;
    measurementId: string;
  };
  ANALYTICS_ENABLED: boolean;
  LOG_LEVEL: 'debug' | 'info' | 'warn' | 'error';
}

const ENV: Environment = (Config.ENVIRONMENT as Environment) || 'development';

const developmentConfig: EnvConfig = {
  API_URL: 'http://localhost:3000/api',
  FIREBASE_CONFIG: {
    apiKey: Config.DEV_FIREBASE_API_KEY,
    // Other Firebase config
  },
  ANALYTICS_ENABLED: false,
  LOG_LEVEL: 'debug',
};

const stagingConfig: EnvConfig = {
  API_URL: 'https://staging-api.unplugged-app.com',
  FIREBASE_CONFIG: {
    apiKey: Config.STAGING_FIREBASE_API_KEY,
    // Other Firebase config
  },
  ANALYTICS_ENABLED: true,
  LOG_LEVEL: 'info',
};

const productionConfig: EnvConfig = {
  API_URL: 'https://api.unplugged-app.com',
  FIREBASE_CONFIG: {
    apiKey: Config.PROD_FIREBASE_API_KEY,
    // Other Firebase config
  },
  ANALYTICS_ENABLED: true,
  LOG_LEVEL: 'error',
};

const envConfig: Record<Environment, EnvConfig> = {
  development: developmentConfig,
  staging: stagingConfig,
  production: productionConfig,
};

export default envConfig[ENV];
```

### Monitoring & Error Tracking

**Implement comprehensive monitoring:**
- Use error tracking services like Sentry
- Implement crash reporting
- Set up performance monitoring
- Create custom analytics events for key user actions

**Example error tracking setup:**
```typescript
import * as Sentry from '@sentry/react-native';

// Initialize Sentry
Sentry.init({
  dsn: 'https://your-sentry-dsn.ingest.sentry.io/project-id',
  environment: Config.ENVIRONMENT,
  release: `${Config.APP_NAME}@${Config.VERSION_NAME}+${Config.VERSION_CODE}`,
  dist: Platform.OS,
  enableAutoSessionTracking: true,
  sessionTrackingIntervalMillis: 30000,
  tracesSampleRate: Config.ENVIRONMENT === 'production' ? 0.1 : 1.0,
});

// Custom error boundary component
function ErrorBoundary({ children }: { children: React.ReactNode }) {
  return (
    <Sentry.ErrorBoundary
      fallback={({ error }) => (
        <View style={styles.errorContainer}>
          <Text style={styles.errorTitle}>Something went wrong</Text>
          <Text style={styles.errorMessage}>{error.message}</Text>
          <Button 
            title="Try Again" 
            onPress={() => RNRestart.Restart()} 
          />
        </View>
      )}
    >
      {children}
    </Sentry.ErrorBoundary>
  );
}

// Custom error logging
function logError(error: Error, context?: Record<string, any>) {
  console.error(error);
  
  Sentry.withScope(scope => {
    if (context) {
      Object.entries(context).forEach(([key, value]) => {
        scope.setExtra(key, value);
      });
    }
    Sentry.captureException(error);
  });
}
```

## Conclusion

Following these best practices will help ensure the Unplugged app is developed to high standards of quality, performance, and user experience. As your first app development project, these guidelines provide a solid foundation for creating a successful product.

Remember that best practices evolve over time, so it's important to stay current with the React Native ecosystem and mobile development trends. Regularly review and update your practices as the project progresses and as you learn from experience.

The most important practice is to maintain a user-centered approach throughout development, ensuring that technical decisions support the app's core mission of improving digital wellbeing.
