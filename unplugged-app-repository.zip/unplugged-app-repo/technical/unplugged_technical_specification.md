# Unplugged App - Technical Specification Document

## 1. Introduction

### 1.1 Purpose
This technical specification document provides comprehensive guidelines for the development of the Unplugged mobile application, a digital wellbeing platform designed to help users create a healthier relationship with technology through mindful digital usage, progressive detox plans, and positive reinforcement.

### 1.2 Scope
This document covers the technical architecture, data models, API specifications, user interfaces, and implementation guidelines for the Unplugged app. It serves as the primary reference for developers, designers, and QA engineers involved in the project.

### 1.3 Definitions and Acronyms
- **API**: Application Programming Interface
- **UI**: User Interface
- **UX**: User Experience
- **MVP**: Minimum Viable Product
- **REST**: Representational State Transfer
- **JWT**: JSON Web Token
- **CRUD**: Create, Read, Update, Delete
- **Digital Wellbeing Score**: A proprietary metric calculated based on user's digital habits

## 2. System Architecture

### 2.1 High-Level Architecture
The Unplugged app will follow a client-server architecture with:
- Mobile applications (iOS and Android) as the client
- RESTful API backend services
- Cloud-based database
- Analytics and machine learning services

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│  Mobile Clients │────▶│  API Services   │────▶│    Databases    │
│  (iOS/Android)  │◀────│                 │◀────│                 │
│                 │     │                 │     │                 │
└─────────────────┘     └────────┬────────┘     └─────────────────┘
                                 │
                                 ▼
                        ┌─────────────────┐
                        │                 │
                        │  ML Services    │
                        │  & Analytics    │
                        │                 │
                        └─────────────────┘
```

### 2.2 Client Architecture
The mobile applications will be built using:
- **Cross-platform framework**: React Native
- **State management**: Redux
- **Navigation**: React Navigation
- **UI components**: Custom component library with Tailwind CSS styling
- **Local storage**: AsyncStorage for non-sensitive data, Keychain/Secure Storage for sensitive data

### 2.3 Server Architecture
The backend will be implemented as:
- **API framework**: Node.js with Express
- **Authentication**: JWT-based authentication
- **Database**: MongoDB for user data, Redis for caching
- **Cloud provider**: AWS
- **Containerization**: Docker with Kubernetes orchestration
- **CI/CD**: GitHub Actions

### 2.4 Third-Party Integrations
- **Analytics**: Firebase Analytics
- **Crash reporting**: Sentry
- **Push notifications**: Firebase Cloud Messaging
- **Health data**: Apple HealthKit and Google Fit
- **Calendar**: Apple Calendar and Google Calendar APIs

## 3. Data Models

### 3.1 User Model
```json
{
  "id": "string (UUID)",
  "email": "string",
  "passwordHash": "string",
  "firstName": "string",
  "lastName": "string",
  "dateOfBirth": "date (optional)",
  "createdAt": "datetime",
  "updatedAt": "datetime",
  "lastLoginAt": "datetime",
  "profilePicture": "string (URL)",
  "preferences": {
    "notifications": {
      "pushEnabled": "boolean",
      "emailEnabled": "boolean",
      "reminderTimes": ["array of times"]
    },
    "theme": "string (light/dark/system)",
    "privacySettings": {
      "shareProgress": "boolean",
      "allowAnonymousDataCollection": "boolean"
    }
  },
  "onboardingCompleted": "boolean",
  "digitalWellbeingScore": "number (0-100)"
}
```

### 3.2 Usage Data Model
```json
{
  "id": "string (UUID)",
  "userId": "string (UUID)",
  "date": "date",
  "totalScreenTime": "number (minutes)",
  "pickups": "number",
  "appUsage": [
    {
      "appName": "string",
      "packageName": "string",
      "category": "string",
      "usageTime": "number (minutes)",
      "openCount": "number"
    }
  ],
  "hourlyBreakdown": [
    {
      "hour": "number (0-23)",
      "screenTime": "number (minutes)",
      "pickups": "number"
    }
  ],
  "focusSessions": [
    {
      "startTime": "datetime",
      "endTime": "datetime",
      "duration": "number (minutes)",
      "wasCompleted": "boolean"
    }
  ]
}
```

### 3.3 Goal Model
```json
{
  "id": "string (UUID)",
  "userId": "string (UUID)",
  "type": "string (enum: screenTime, pickups, appLimit, focusTime)",
  "target": "number",
  "current": "number",
  "startDate": "date",
  "endDate": "date (optional)",
  "recurrence": "string (enum: daily, weekly, monthly, none)",
  "status": "string (enum: active, completed, failed, paused)",
  "progress": "number (percentage)",
  "relatedApp": "string (optional)",
  "createdAt": "datetime",
  "updatedAt": "datetime"
}
```

### 3.4 Plan Model
```json
{
  "id": "string (UUID)",
  "name": "string",
  "description": "string",
  "difficulty": "string (enum: beginner, intermediate, advanced)",
  "duration": "number (days)",
  "category": "string (enum: focus, sleep, social, general)",
  "isCustom": "boolean",
  "createdBy": "string (UUID, null if system plan)",
  "isPublic": "boolean",
  "rating": "number (0-5)",
  "ratingCount": "number",
  "steps": [
    {
      "day": "number",
      "title": "string",
      "description": "string",
      "tasks": [
        {
          "id": "string",
          "description": "string",
          "isCompleted": "boolean"
        }
      ]
    }
  ],
  "createdAt": "datetime",
  "updatedAt": "datetime"
}
```

### 3.5 Achievement Model
```json
{
  "id": "string (UUID)",
  "userId": "string (UUID)",
  "type": "string (enum: streak, milestone, challenge, custom)",
  "title": "string",
  "description": "string",
  "iconUrl": "string",
  "unlockedAt": "datetime",
  "progress": "number (percentage)",
  "isHidden": "boolean",
  "relatedGoalId": "string (UUID, optional)",
  "relatedPlanId": "string (UUID, optional)",
  "metadata": "object (flexible structure based on achievement type)"
}
```

### 3.6 Community Challenge Model
```json
{
  "id": "string (UUID)",
  "title": "string",
  "description": "string",
  "startDate": "datetime",
  "endDate": "datetime",
  "participantCount": "number",
  "category": "string",
  "rules": "string",
  "createdBy": "string (UUID, null if system challenge)",
  "isActive": "boolean",
  "participants": [
    {
      "userId": "string (UUID)",
      "joinedAt": "datetime",
      "progress": "number (percentage)",
      "status": "string (enum: active, completed, dropped)"
    }
  ],
  "createdAt": "datetime",
  "updatedAt": "datetime"
}
```

## 4. API Specifications

### 4.1 Authentication Endpoints

#### 4.1.1 User Registration
- **Endpoint**: `POST /api/auth/register`
- **Request Body**:
  ```json
  {
    "email": "string",
    "password": "string",
    "firstName": "string",
    "lastName": "string"
  }
  ```
- **Response**:
  ```json
  {
    "token": "string (JWT)",
    "user": {
      "id": "string",
      "email": "string",
      "firstName": "string",
      "lastName": "string"
    }
  }
  ```

#### 4.1.2 User Login
- **Endpoint**: `POST /api/auth/login`
- **Request Body**:
  ```json
  {
    "email": "string",
    "password": "string"
  }
  ```
- **Response**: Same as registration response

#### 4.1.3 Social Authentication
- **Endpoint**: `POST /api/auth/social`
- **Request Body**:
  ```json
  {
    "provider": "string (enum: google, apple)",
    "token": "string"
  }
  ```
- **Response**: Same as registration response

#### 4.1.4 Password Reset
- **Endpoint**: `POST /api/auth/reset-password`
- **Request Body**:
  ```json
  {
    "email": "string"
  }
  ```
- **Response**:
  ```json
  {
    "message": "string",
    "success": "boolean"
  }
  ```

### 4.2 User Endpoints

#### 4.2.1 Get User Profile
- **Endpoint**: `GET /api/users/me`
- **Headers**: `Authorization: Bearer {token}`
- **Response**:
  ```json
  {
    "id": "string",
    "email": "string",
    "firstName": "string",
    "lastName": "string",
    "profilePicture": "string",
    "preferences": { ... },
    "digitalWellbeingScore": "number",
    "createdAt": "datetime"
  }
  ```

#### 4.2.2 Update User Profile
- **Endpoint**: `PUT /api/users/me`
- **Headers**: `Authorization: Bearer {token}`
- **Request Body**: User fields to update
- **Response**: Updated user object

#### 4.2.3 Update User Preferences
- **Endpoint**: `PUT /api/users/me/preferences`
- **Headers**: `Authorization: Bearer {token}`
- **Request Body**: Preference fields to update
- **Response**: Updated preferences object

### 4.3 Usage Data Endpoints

#### 4.3.1 Submit Usage Data
- **Endpoint**: `POST /api/usage`
- **Headers**: `Authorization: Bearer {token}`
- **Request Body**: Usage data object
- **Response**: Saved usage data object with analysis

#### 4.3.2 Get Usage Summary
- **Endpoint**: `GET /api/usage/summary`
- **Headers**: `Authorization: Bearer {token}`
- **Query Parameters**:
  - `period`: string (enum: day, week, month, year)
  - `date`: string (ISO date, optional)
- **Response**:
  ```json
  {
    "period": "string",
    "startDate": "date",
    "endDate": "date",
    "totalScreenTime": "number",
    "averageScreenTime": "number",
    "totalPickups": "number",
    "averagePickups": "number",
    "topApps": [ ... ],
    "peakUsageHours": [ ... ],
    "trend": "string (enum: increasing, decreasing, stable)",
    "changePercentage": "number"
  }
  ```

#### 4.3.3 Get App Usage Details
- **Endpoint**: `GET /api/usage/apps`
- **Headers**: `Authorization: Bearer {token}`
- **Query Parameters**: Same as summary
- **Response**: Detailed app usage statistics

### 4.4 Goals Endpoints

#### 4.4.1 Create Goal
- **Endpoint**: `POST /api/goals`
- **Headers**: `Authorization: Bearer {token}`
- **Request Body**: Goal object
- **Response**: Created goal object

#### 4.4.2 Get User Goals
- **Endpoint**: `GET /api/goals`
- **Headers**: `Authorization: Bearer {token}`
- **Query Parameters**:
  - `status`: string (enum: active, completed, all)
- **Response**: Array of goal objects

#### 4.4.3 Update Goal
- **Endpoint**: `PUT /api/goals/{goalId}`
- **Headers**: `Authorization: Bearer {token}`
- **Request Body**: Goal fields to update
- **Response**: Updated goal object

### 4.5 Plans Endpoints

#### 4.5.1 Get Available Plans
- **Endpoint**: `GET /api/plans`
- **Headers**: `Authorization: Bearer {token}`
- **Query Parameters**:
  - `category`: string (optional)
  - `difficulty`: string (optional)
  - `duration`: number (optional)
- **Response**: Array of plan objects

#### 4.5.2 Get Plan Details
- **Endpoint**: `GET /api/plans/{planId}`
- **Headers**: `Authorization: Bearer {token}`
- **Response**: Detailed plan object

#### 4.5.3 Start Plan
- **Endpoint**: `POST /api/plans/{planId}/start`
- **Headers**: `Authorization: Bearer {token}`
- **Response**: User plan progress object

#### 4.5.4 Update Plan Progress
- **Endpoint**: `PUT /api/plans/{planId}/progress`
- **Headers**: `Authorization: Bearer {token}`
- **Request Body**:
  ```json
  {
    "day": "number",
    "completedTasks": ["array of task IDs"]
  }
  ```
- **Response**: Updated progress object

### 4.6 Achievements Endpoints

#### 4.6.1 Get User Achievements
- **Endpoint**: `GET /api/achievements`
- **Headers**: `Authorization: Bearer {token}`
- **Query Parameters**:
  - `type`: string (optional)
  - `status`: string (enum: unlocked, locked, all)
- **Response**: Array of achievement objects

#### 4.6.2 Get Achievement Details
- **Endpoint**: `GET /api/achievements/{achievementId}`
- **Headers**: `Authorization: Bearer {token}`
- **Response**: Detailed achievement object

### 4.7 Community Endpoints

#### 4.7.1 Get Active Challenges
- **Endpoint**: `GET /api/community/challenges`
- **Headers**: `Authorization: Bearer {token}`
- **Response**: Array of challenge objects

#### 4.7.2 Join Challenge
- **Endpoint**: `POST /api/community/challenges/{challengeId}/join`
- **Headers**: `Authorization: Bearer {token}`
- **Response**: Updated challenge object with user participation

#### 4.7.3 Get Community Stats
- **Endpoint**: `GET /api/community/stats`
- **Headers**: `Authorization: Bearer {token}`
- **Response**: Community-wide statistics

## 5. Mobile App Implementation

### 5.1 App Structure
The app will follow a modular structure with the following main directories:
```
/src
  /assets        # Images, fonts, and other static assets
  /components    # Reusable UI components
    /common      # Basic UI elements (buttons, inputs, etc.)
    /screens     # Screen-specific components
  /hooks         # Custom React hooks
  /navigation    # Navigation configuration
  /screens       # Screen components
  /services      # API and third-party service integrations
  /store         # Redux store configuration
    /actions     # Redux actions
    /reducers    # Redux reducers
    /selectors   # Redux selectors
  /styles        # Global styles and theme configuration
  /utils         # Utility functions
```

### 5.2 Key Screens Implementation

#### 5.2.1 Onboarding Flow
- Welcome Screen
- Digital Habits Assessment (3 screens)
- Goal Setting Screen
- Dashboard Introduction

#### 5.2.2 Main Dashboard
- Digital Score visualization
- Usage Patterns section
- Goal Progress tracking
- Insights section
- Navigation to other main sections

#### 5.2.3 Tools Section
- Tools Home Screen
- Intention Setter Tool
- Focus Mode Tool
- Mindful Break Tool
- Usage Awareness Tool

#### 5.2.4 Plans Section
- Plans Home Screen
- Plan Detail Screen
- Active Plan Screen
- Plan Creation Screen
- Plan Completion Screen

#### 5.2.5 Community Section
- Community Home Screen
- Group Challenge Screen
- Community Forum Screen
- Success Stories Screen
- Accountability Partner Screen

#### 5.2.6 Profile Section
- Profile Home Screen
- Achievements Screen
- Settings Screen
- Stats & Insights Screen
- Celebration Screen

### 5.3 Native Features Integration

#### 5.3.1 Usage Tracking
- **iOS**: Use ScreenTime API (requires special entitlement)
- **Android**: Use UsageStatsManager API (requires permission)
- **Fallback**: Manual tracking with reminders

#### 5.3.2 Notifications
- Schedule local notifications for reminders
- Support for silent notifications
- Custom notification channels on Android
- Focus mode integration with Do Not Disturb

#### 5.3.3 Background Processing
- Periodic sync of usage data
- Background goal progress updates
- Silent push notifications for data refresh

#### 5.3.4 Widgets
- Digital wellbeing score widget
- Daily progress widget
- Focus mode quick toggle widget

## 6. Backend Implementation

### 6.1 Server Components
- API Server (Express.js)
- Authentication Service
- Data Processing Service
- Machine Learning Service
- Notification Service

### 6.2 Database Schema
MongoDB collections will mirror the data models defined in section 3, with appropriate indexes for query optimization.

### 6.3 Caching Strategy
- Redis will be used for caching:
  - User sessions
  - Frequently accessed data (plans, challenges)
  - API rate limiting

### 6.4 Security Measures
- JWT authentication with short expiration
- HTTPS for all communications
- Input validation and sanitization
- Rate limiting for API endpoints
- Data encryption for sensitive information
- Regular security audits

## 7. Analytics and Machine Learning

### 7.1 Analytics Implementation
- Track user engagement metrics
- Monitor feature usage
- Analyze retention and churn
- Measure goal completion rates
- Track digital wellbeing score improvements

### 7.2 Machine Learning Models
- Usage pattern recognition
- Personalized goal recommendations
- Content recommendation system
- Anomaly detection for usage spikes
- Prediction of potential digital wellbeing issues

### 7.3 Digital Wellbeing Score Algorithm
The proprietary Digital Wellbeing Score will be calculated based on:
- Screen time (duration and distribution)
- Pickup frequency
- App usage categories
- Focus session completion
- Goal achievement
- Sleep pattern correlation

## 8. Testing Strategy

### 8.1 Unit Testing
- Frontend: Jest + React Testing Library
- Backend: Mocha + Chai

### 8.2 Integration Testing
- API endpoint testing with Supertest
- Service integration tests

### 8.3 End-to-End Testing
- Mobile app testing with Detox
- User flow testing with Cypress

### 8.4 Performance Testing
- API load testing with k6
- Mobile app performance profiling
- Database query optimization testing

### 8.5 User Testing
- Usability testing protocol
- A/B testing framework
- Beta testing program

## 9. Deployment and DevOps

### 9.1 CI/CD Pipeline
- GitHub Actions for automated testing and deployment
- Separate pipelines for development, staging, and production

### 9.2 Environment Configuration
- Development
- Staging
- Production

### 9.3 Monitoring and Logging
- Application monitoring with New Relic
- Error tracking with Sentry
- Centralized logging with ELK stack
- Custom alerts and dashboards

### 9.4 Backup and Recovery
- Automated database backups
- Disaster recovery plan
- Data retention policies

## 10. Implementation Roadmap

### 10.1 Phase 1: MVP (3 months)
- Basic user authentication
- Onboarding flow
- Dashboard with usage tracking
- Simple goal setting
- Core settings

### 10.2 Phase 2: Enhanced Features (2 months)
- Tools section implementation
- Plans section with predefined plans
- Achievements system
- Improved analytics

### 10.3 Phase 3: Community Features (2 months)
- Community challenges
- Forums and success stories
- Accountability partners
- Social sharing

### 10.4 Phase 4: Advanced Features (3 months)
- Machine learning recommendations
- Advanced insights
- Custom plan creation
- Widget support
- API for third-party integrations

## 11. Appendices

### 11.1 Technology Stack Summary
- **Frontend**: React Native, Redux, Tailwind CSS
- **Backend**: Node.js, Express, MongoDB, Redis
- **Infrastructure**: AWS, Docker, Kubernetes
- **DevOps**: GitHub Actions, ELK Stack, New Relic, Sentry

### 11.2 Third-Party Libraries and Dependencies
- Authentication: Passport.js, JWT
- Data visualization: Victory Native
- State management: Redux Toolkit
- Forms: Formik, Yup
- UI components: React Native Paper
- Navigation: React Navigation
- HTTP client: Axios
- Date handling: date-fns
- Analytics: Firebase Analytics

### 11.3 API Documentation
Detailed API documentation will be available via Swagger UI at `/api-docs` endpoint.

### 11.4 Glossary
- **Digital Wellbeing**: The state of one's health and wellness as it relates to digital technology use
- **Digital Detox**: A period where a person refrains from using electronic devices
- **Screen Time**: The amount of time spent using a device with a screen
- **Pickup**: An instance of activating a device from sleep or lock state
- **Focus Session**: A dedicated period of time for concentrated work without digital distractions
- **Digital Wellbeing Score**: A proprietary metric that quantifies a user's digital health
